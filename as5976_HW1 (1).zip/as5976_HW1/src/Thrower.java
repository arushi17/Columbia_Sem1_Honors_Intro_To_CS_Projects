import java.util.*;
import java.text.DecimalFormat;

/**
 * This is the thrower class. Its purpose is to provide one side of the throws for the game. It can be thought of as the computer's side.
 * Thrower creates the nested EnumMap data structures that are used for storing the rules of the game.
 * It also contains methods to compare the throws, or moves, made from the Talker class to those made from the Thrower class, as well as display stats about the game.
 * There are three strategies for getting the computer's throw: randomly choosing a throw (see RandomStrategy class), working one step ahead of the human (see ReflectorStrategy class),
 * and working against both Talker strategies (see RevengeStrategy class).
 * 
 * @author Arushi Sahai as5976
 *
 */
public class Thrower {

	public Thrower(ThrowerStrategyType strategyType) {
		rules = new EnumMap<ThrowType,EnumMap<ThrowType,WinType>>(ThrowType.class);
		
		// Note: maps are structured from loser to winner with the verb connecting them
		EnumMap<ThrowType,WinType> rockMap = new EnumMap<ThrowType,WinType>(ThrowType.class);
		EnumMap<ThrowType,WinType> paperMap = new EnumMap<ThrowType,WinType>(ThrowType.class);
		EnumMap<ThrowType,WinType> scissorMap = new EnumMap<ThrowType,WinType>(ThrowType.class);
		
		EnumMap<ThrowType,WinType> lizardMap = new EnumMap<ThrowType,WinType>(ThrowType.class);
		EnumMap<ThrowType,WinType> spockMap = new EnumMap<ThrowType,WinType>(ThrowType.class);
		
		rockMap.put(ThrowType.PAPER, WinType.COVERS);
		rockMap.put(ThrowType.SPOCK, WinType.VAPORIZES);
		paperMap.put(ThrowType.SCISSORS, WinType.CUTS);
		paperMap.put(ThrowType.LIZARD, WinType.EATS);
		scissorMap.put(ThrowType.ROCK, WinType.BREAKS);
		scissorMap.put(ThrowType.SPOCK, WinType.SMASHES);
		
		lizardMap.put(ThrowType.ROCK, WinType.CRUSHES);
		lizardMap.put(ThrowType.SCISSORS, WinType.DECAPITATES);
		spockMap.put(ThrowType.PAPER, WinType.DISPROVES);
		spockMap.put(ThrowType.LIZARD, WinType.POISONS);
		
		rules.put(ThrowType.ROCK, rockMap);
		rules.put(ThrowType.PAPER, paperMap);
		rules.put(ThrowType.SCISSORS, scissorMap);
		
		rules.put(ThrowType.LIZARD, lizardMap);
		rules.put(ThrowType.SPOCK, spockMap);
		
		if (strategyType == ThrowerStrategyType.RANDOM) {
			strategy = new RandomStrategy();
		}
		else if (strategyType == ThrowerStrategyType.RECORDER) {
			strategy = new RecorderStrategy();
		}
		else if (strategyType == ThrowerStrategyType.REVENGE) {
			strategy = new RevengeStrategy();
		}
	}
	
	public static ThrowType getComputerThrow() {
		return strategy.generateThrow();
	}
	
	public static void compareMove(ThrowType userThrow, ThrowType computerThrow) {
		strategy.recordThrow(userThrow);
		
		if(userThrow == computerThrow) {
			numDraws++;
			System.out.println("Draw.");
			return;
		}
		EnumMap<ThrowType,WinType> computerWinMap = rules.get(userThrow); 
		if (computerWinMap.containsKey(computerThrow)) {
			WinType winVerb = computerWinMap.get(computerThrow);
			numComputerWins++;
			System.out.println("Computer wins: " + getWinStatement(computerThrow, userThrow, winVerb));
		}
		else {
			numUserWins++;
			EnumMap<ThrowType,WinType> userWinMap = rules.get(computerThrow);
			WinType winVerb = userWinMap.get(userThrow); // guaranteed to exist
			System.out.println("User wins: " + getWinStatement(userThrow, computerThrow, winVerb));
		}
	}
	
	private static String getWinStatement(ThrowType winningThrow, ThrowType losingThrow, WinType verb) {
		String winStatement = winningThrow.toString() + " " + verb.toString() + " " + losingThrow.toString();
		return winStatement;
	}
	
	public static void printStats() {
		double totalGames = numUserWins + numComputerWins + numDraws;
		String percentUserWins = new DecimalFormat("#.#").format((numUserWins/totalGames) * 100);
		String percentComputerWins = new DecimalFormat("#.#").format((numComputerWins/totalGames) * 100);
		String percentDraws = new DecimalFormat("#.#").format((numDraws/totalGames) * 100);
		
		System.out.println("\nTotal games played: " + (numUserWins + numComputerWins + numDraws));
		System.out.println("User wins: " + numUserWins + " (" + percentUserWins + "% of total games)");
		System.out.println("Computer wins: " + numComputerWins + " (" + percentComputerWins + "% of total games)");
		System.out.println("Draws: " + numDraws + " (" + percentDraws + "% of total games)");
	}
	
	private static EnumMap<ThrowType,EnumMap<ThrowType,WinType>> rules;
	private static Strategy strategy;
	private static int numUserWins = 0;
	private static int numComputerWins = 0;
	private static int numDraws = 0;
	
	private ThrowType pastUserThrow = ThrowType.SPOCK; // used by revenge 
	
	/**
	 * This is the RandomStrategy class. Its purpose is to provide random throws of R, P, S, L, or K. 
	 * It implements the Strategy interface so it contains methods to generate a throw and record a throw.
	 * 
	 * @author Arushi Sahai as5976
	 *
	 */
	
	public class RandomStrategy implements Strategy {
		
		public RandomStrategy() {
			
		}
		
		public ThrowType generateThrow() {
			Random randomGen = new Random();
			int randThrow = randomGen.nextInt(5);
			
			if (randThrow == 0) {
				return ThrowType.ROCK;
			}
			else if (randThrow == 1) {
				return ThrowType.PAPER;
			}
			else if (randThrow == 2) {
				return ThrowType.SCISSORS;
			}
			else if (randThrow == 3) {
				return ThrowType.LIZARD;
			}
			else {
				return ThrowType.SPOCK;
			}
		}
		
		public void recordThrow(ThrowType userThrow) {
			
		}
	}
	
	/**
	 * This is the RecorderStrategy class. Its purpose is to record the user's most frequent throws, 
	 * and the throw with the highest value is predicted to be the next throw. 
	 * The computer's throw is then the move that wins over the user's predicted throw.
	 * RecorderStrategy implements the Strategy interface so it contains methods to generate a throw and record a throw.
	 * 
	 * @author Arushi Sahai as5976
	 *
	 */
	
	public class RecorderStrategy implements Strategy {
		
		public RecorderStrategy() {
			
		}
		
		public ThrowType generateThrow() {
			ThrowType userThrow = predictNextUserMove();
			System.out.println("rules.get(userThrow).keySet(): " + rules.get(userThrow).keySet());
			System.out.println("rules.get(userThrow).keySet().iterator().next(): " + rules.get(userThrow).keySet().iterator().next());
			ThrowType computerThrow = rules.get(userThrow).keySet().iterator().next();
			return computerThrow;
		}
		
		private ThrowType predictNextUserMove() {
			int highestFrequency = 0;
			ThrowType highestFrequencyThrow = ThrowType.ROCK;
			for (int i = 0; i < userThrowFrequencies.length; i++) {
				if (userThrowFrequencies[i] > highestFrequency) {
					highestFrequency = userThrowFrequencies[i];
					highestFrequencyThrow = ThrowType.values()[i];
				}
			}
			return highestFrequencyThrow;
		}
		
		public void recordThrow(ThrowType userThrow) {
			userThrowFrequencies[userThrow.ordinal()]++;
		}
		
		private int[] userThrowFrequencies = new int[ThrowType.values().length];
	}
	
	/**
	 * This is the RevengeStrategy class. Its purpose is to guess which strategy the Talker is implementing (either Rotator or Reflector). 
	 * The computer's throw is then the move that wins over the user's predicted throw.
	 * RevengeStrategy implements the Strategy interface so it contains methods to generate a throw and record a throw.
	 * 
	 * Testing: using the "best" value of N found (large N):
	 * Total games played: 10000
	 * User wins: 52 (0.5% of total games)
	 * Computer wins: 9948 (99.5% of total games)
	 * Draws: 0 (0% of total games)
	 * 
	 * Note that this strategy does not work well for small N, particularly N=1. 
	 * 
	 * @author Arushi Sahai as5976
	 *
	 */
	
	public class RevengeStrategy implements Strategy {
		
		public RevengeStrategy() {
			
		}
		
		// organize generating throws of both method revenges
		public ThrowType generateThrow() {
			ThrowType bestComputerThrow = rules.get(predictNextUserThrow()).keySet().iterator().next();
			System.out.println("computer throw: " + bestComputerThrow);
			
			// save state for next time
			lastLastComputerThrow = lastComputerThrow;
			lastComputerThrow = bestComputerThrow;
			return bestComputerThrow;
		}
		
		private ThrowType predictNextUserThrow() {
			ThrowType nextThrow = ThrowType.ROCK; // also placeholder
			System.out.println("isRotator: " + isRotator);
			if (isRotator) {
				nextThrow = getUserNextThrowRotator();
			}
			else { // sim will reflect what comp did last time. therefore prediction of sim next move is what comp did last time.
				nextThrow = lastComputerThrow;
			}
			System.out.println("next predicted user throw: " + nextThrow);
			return nextThrow;
		}
		
		public void recordThrow(ThrowType userThrow) {
			if (isRotator) {
				int ordinalLastUserThrow = lastUserThrow.ordinal();
				if ((++ordinalLastUserThrow) % throwTypes.length != userThrow.ordinal()) {
					isRotator = false;
				}
			}
			else {
				if (userThrow != lastLastComputerThrow) {
					isRotator = true;
				}
			}
			lastUserThrow = userThrow;
		}
		
		// first checks to see if user is using rotator method if so, returns users next throw
		private ThrowType getUserNextThrowRotator() {
			int ordinalLastUserThrow = lastUserThrow.ordinal();
			int ordinalNextUserThrow = (++ordinalLastUserThrow) % throwTypes.length; 
			System.out.println("Last user throw: " + lastUserThrow.toString() + "\nNext user throw: " + throwTypes[ordinalNextUserThrow]);
			return throwTypes[ordinalNextUserThrow];
		}
		
		private boolean isRotator = true;
		private ThrowType lastComputerThrow = ThrowType.ROCK;
		private ThrowType lastLastComputerThrow = ThrowType.ROCK;
		private ThrowType lastUserThrow = ThrowType.ROCK;
		private ThrowType[] throwTypes = ThrowType.values();
	}
}
