/**
 * This file contains specifications for an enum of the five different throw types.
 * 
 * @author Arushi Sahai as5976
 *
 */

public enum ThrowType {
	ROCK, PAPER, SCISSORS, LIZARD, SPOCK
}