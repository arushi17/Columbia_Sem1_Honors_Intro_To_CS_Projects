/**
 * This file contains specifications for a Strategy interface that is used to unify the three types of Thrower strategies.
 * 
 * @author Arushi Sahai as5976
 *
 */

public interface Strategy {
	public ThrowType generateThrow();
	public void recordThrow(ThrowType userThrow);
}
