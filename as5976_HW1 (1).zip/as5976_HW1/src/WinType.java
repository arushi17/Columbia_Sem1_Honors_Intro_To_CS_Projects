/**
 * This file contains specifications for an enum of the ten different win types.
 * 
 * @author Arushi Sahai as5976
 *
 */
public enum WinType {
	COVERS, CRUSHES, CUTS, SMASHES, VAPORIZES, EATS, DISPROVES, POISONS, DECAPITATES, BREAKS
}