import java.io.IOException;

/**
 * This is the Runner class, which runs the game "Rock, paper, scissors, lizard, spock" (an extension of "Rock, paper, scissors"). 
 * It uses two main classes, Talker (which can be thought of like a user), and Thrower (which can be thought of like a computer).
 * It has multiple strategies for both Talker and Thrower.
 * Note: this program uses a significant amount of Enum data structures to encapsulate the RPSLK (a "real world" idea) in the Talker class. 
 * 
 * @author Arushi Sahai as5976
 *
 */

/**
* TESTING DOCUMENTATION:
* 
* For step 1: RPS with random strategy
* User wins: 37 (37% of total games)
* Computer wins: 26 (26% of total games)
* Draws: 37 (37% of total games)
* There is a fairly even split here.
* 
* For step 2: RPS with recorder strategy
* User wins: 23 (23% of total games)
* Computer wins: 54 (54% of total games)
* Draws: 23 (23% of total games)
* The computer wins a lot more!
* 
* For step 3: RPSLK with recorder strategy
* User wins: 28 (28% of total games)
* Computer wins: 62 (62% of total games)
* Draws: 10 (10% of total games)
* The computer wins a lot more!
* 
* For step 3: RPSLK with random strategy
* User wins: 45 (45% of total games)
* Computer wins: 38 (38% of total games)
* Draws: 17 (17% of total games)
* Again a fairly even split between user and computer.
* 
* For step 4: find the best "N". See Sim class.
* 
* For step 5: compare Step 4 to Step 5. See RevengeStrategy class.
*/

public class Runner {

	public static void main(String args[]) { 
		Talker talker = new Talker(TalkerStrategyType.USER, N); 
		Thrower thrower = new Thrower(ThrowerStrategyType.RANDOM); 
		try {
			talker.displayRules();
			for(int i = 0; i < NUM_LOOPS_PER_GAME; i++) { 
				ThrowType userThrow = talker.getUserThrow();
				ThrowType computerThrow = thrower.getComputerThrow();
				thrower.compareMove(userThrow, computerThrow);
				talker.recordComputerThrow(computerThrow);
			}
		}
		catch (IOException e) {
		}
		System.out.println("Quitting game.");
		thrower.printStats();
	}
	
	private static final int NUM_LOOPS_PER_GAME = 10000;
	private static final int N = 20;
}
