/**
 * This file contains specifications for an enum of the two types of talker strategies.
 * 
 * @author Arushi Sahai as5976
 *
 */

public enum TalkerStrategyType {
	USER, SIM
}
