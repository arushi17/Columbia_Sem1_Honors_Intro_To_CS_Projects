/**
 * This file contains specifications for an enum of the three types of thrower strategies.
 * 
 * @author Arushi Sahai as5976
 *
 */

public enum ThrowerStrategyType {
	RANDOM, RECORDER, REVENGE
}
