import java.util.Random;
import java.util.Scanner;

import java.io.IOException;

/**
 * This is the Talker class. Its purpose is to provide one side of the throws for the game. It can be thought of as the user's side.
 * Talker contains methods to display the rules of the game and get the user's throw as well as two classes to provide user throws.
 * There are two strategies for getting the user's throw: the user could input it manually (see UserInput class) or it could be simulated (see Sim class).
 * Significant extensions from RPS to RPSLK were made here.
 * 
 * @author Arushi Sahai as5976
 *
 */

public class Talker {

	public Talker (TalkerStrategyType strategyTypeIn, int N) {
		strategyType = strategyTypeIn;
		if (strategyType == TalkerStrategyType.USER) {
			userInput = new UserInput();
		}
		else {
			sim = new Sim(N);
		}
	}
		
	/**
	 * Displays the rules of the RPSLK extended game.
	 */
	public static void displayRules() {
		System.out.println("Welcome to rock, paper, scissors, lizard, spock! "
				+ "Choose one of rock, paper, scissors, lizard, or spock as your move.\n"
				+ "\nRules to win: Scissors cuts paper, paper covers rock, rock crushes "
				+ "lizard, lizard poisons Spock, Spock smashes scissors, \nscissors "
				+ "decapitates lizard, lizard eats paper, paper disproves Spock, "
				+ "Spock vaporizes rock, and as it always has, "
				+ "rock breaks scissors.\n");
	}
	
	/**
	 * Generates the throw created by the Talker class. Catches the "User wants to quit game." exception.
	 * 
	 * @return the generated UserInput or Sim throw
	 */
	public static ThrowType getUserThrow() throws IOException {
		if (strategyType == TalkerStrategyType.USER) {
			try {
				return userInput.getUserInput();
			}
			catch (IOException e) {
				throw new IOException("User wants to quit game.");
			}
		}
		else {
			return sim.generateThrow();
		}
	}
	
	/**
	 * Records the computer's throw for the different strategy classes. 
	 * 
	 * @param computerThrowIn computer's last throw
	 */
	public static void recordComputerThrow(ThrowType computerThrowIn) {
		computerThrow = computerThrowIn;
	}
	
	private static Scanner CONSOLE = new Scanner(System.in);
	private static TalkerStrategyType strategyType;
	private static UserInput userInput;
	private static Sim sim;
	private static ThrowType computerThrow = ThrowType.ROCK; // supposed to play what the computer played last time, so this is "last time"
	
	/**
	 * This is the Sim class. Its purpose is to provide two strategies of simulated throws: Rotator and Reflector.
	 * The rotator strategy rotates the user's throws through R, P, S, L, and K continuously.
	 * The reflector strategy has the user throw be whatever the computer, or the Thrower class, played last.
	 * The two strategies are alternated between after each has made a final value of "N" rounds, which is determined at the highest level.
	 * 
	 * Testing: I found that the "best" value of N did not matter once N was large enough in comparison to the total number of games played.
	 * For instance, if the total games played was 10000, it did not matter whether N was 20 or 1000. The user consistently won 40% of the time.
	 * 
	 * @author Arushi Sahai as5976
	 *
	 */
	
	public class Sim {
		
		public Sim(int NIn) {
			N = NIn;
		}
		
		/**
		 * Generates a throw, using either Rotator or Reflector strategies.
		 * 
		 * @return the generated throw to the Talker class
		 */
		public ThrowType generateThrow() {
			System.out.println("numCurrentStrategy: " + numCurrentStrategy);
			numCurrentStrategy++;

			if (numCurrentStrategy >= N) {
				isRotator = !isRotator;
				numCurrentStrategy = 0;
			}
			
			if (isRotator) {
				return rotatorStrategy();
			}
			else {
				return reflectorStrategy();
			}
		}
		
		/**
		 * Implements the Rotator strategy.
		 * 
		 * @return the generated throw
		 */
		private ThrowType rotatorStrategy() {
			if (i == throwTypes.length - 1) {
				i = 0;
			}
			else {					
				i++;
			}
			return throwTypes[i];
		}
		
		/**
		 * Implements the Reflector strategy.
		 * 
		 * @return the generated throw
		 */
		private ThrowType reflectorStrategy() {
			return computerThrow;
		}
		
		private TalkerStrategyType strategyType;
		private ThrowType[] throwTypes = ThrowType.values();
		private int i = throwTypes.length - 1;
		private int N;
		private int numCurrentStrategy = 0;
		private boolean isRotator = true;

	}
	
	/**
	 * This is the UserInput class. Its purpose is to take user's manual input, with error checking, and turn it into an RPSLK throw.
	 * It contains methods to interact with the user via the scanner, check for errors, then convert their String input into an enum data structure.
	 * The enum data structures are used throughout this program to keep the real-world knowledge of "rock", "paper", "scissors", "lizard", and "spock" in one class (Talker).
	 * 
	 * @author Arushi Sahai as5976
	 *
	 */
	
	public class UserInput {
		
		public UserInput() {
			
		}
		
		/**
		 * Uses the console to get a String for the user's input of 'r', 'p', 's', 'l', or 'k'.
		 * @return a ThrowType enum corresponding to the user's input
		 * @throws IOException "User wants to quit game." to handle when the user wants to quit the game
		 */
		public ThrowType getUserInput() throws IOException {
			System.out.println("\nWhat is your move? Enter one of the following: 'r' for rock,"
					+ " 'p' for paper, 's' for scissors, 'l' for lizard, "
					+ "'k' for spock, 'q' for QUIT.");
			String userInput = CONSOLE.nextLine().toLowerCase();
			while(userInputNotValid(userInput)) {
				userInput = CONSOLE.nextLine();
			}
			try {
				return convertToEnum(userInput);
			}
			catch (IOException e) {
				throw new IOException("User wants to quit game.");
			}
		}
		
		/**
		 * Error checking for valid user input
		 * @param userInput 
		 * @return a boolean declaring whether the user's input was valid or not
		 */
		private boolean userInputNotValid(String userInput) {
			if((userInput.compareTo("r") != 0) && (userInput.compareTo("p") != 0) && 
					(userInput.compareTo("s") != 0) && (userInput.compareTo("l") != 0) 
					&& (userInput.compareTo("k") != 0) && (userInput.compareTo("q") != 0)) {
				System.out.println("Please only enter one of the following: "
						+ "'r', 'p', 's', 'l', 'k', or 'q'.\n");
				return true;
			}
			return false;
		}
		
		/**
		 * 
		 * @param userInput
		 * @return
		 * @throws IOException
		 */
		private ThrowType convertToEnum(String userInput) throws IOException {
			switch (userInput) {
			case "r":
				return ThrowType.ROCK;
			case "p":
				return ThrowType.PAPER;
			case "s":
				return ThrowType.SCISSORS;
			case "l":
				return ThrowType.LIZARD;
			case "k":
				return ThrowType.SPOCK;
			default:
				throw new IOException("User wants to quit game.");
			}
			
		}

	}
	
}
