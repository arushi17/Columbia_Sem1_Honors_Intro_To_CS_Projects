/**
 * Command object that holds the command signifier, line (if present), text (if present). 
 * @author arushi
 *
 */
public class Command {

	/**
	 * Constructor
	 */
	public Command() {

	}
	
	/**
	 * Getter for command signifier
	 * @return commandSignifier
	 */
	public char getCommandSignifier() {
		return commandSignifier;
	}
	
	/**
	 * Getter for line
	 * @return line
	 */
	public int getLine() {
		return line;
	}
	
	/**
	 * Getter for text
	 * @return text
	 */
	public String getText() {
		return text;
	}
	
	/**
	 * Setter for command signifier
	 * @param commandSignifierIn
	 */
	public void setCommandSignifier(char commandSignifierIn) {
		commandSignifier = commandSignifierIn;
	}
	
	/**
	 * Setter for line
	 * @param lineIn
	 */
	public void setLine(int lineIn) {
		line = lineIn;
	}
	
	/**
	 * Setter for text
	 * @param textIn
	 */
	public void setText(String textIn) {
		text = textIn;
	}
	
	private char commandSignifier = ' ';
	private int line = 0;
	private String text = "";
}
