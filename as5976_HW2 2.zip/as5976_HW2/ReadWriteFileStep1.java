import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Contains helper methods for reading and writing a file for step 1.
 * @author Arushi Sahai as5976
 *
 */
public class ReadWriteFileStep1 {
	
	/**
	 * Code for reading a file
	 * Note: code for reading file from https://stackoverflow.com/questions/48961788/reading-a-txt-file-using-bufferedreader-and-filereader?noredirect=1&lq=1
	 * @param parsedCommand 
	 * @param fileText
	 * @param stateChanged
	 * @return stateChanged boolean (fileText is already modified because only the reference was passed in, but stateChanged is not)
	 */
	public static boolean readFile(Command parsedCommand, ArrayList<String> fileText, boolean stateChanged) {	
		String fileName = parsedCommand.getText();
		if (fileName.isEmpty()) {
			System.out.println("Creating blank file.");
			stateChanged = false;
		}
		else {
			stateChanged = readFile(fileName, fileText, stateChanged);
		}
		return stateChanged;
	}
	
	/**
	 * Code for writing a file
	 * Note: code to write file from https://stackoverflow.com/questions/6548157/how-to-write-an-arraylist-of-strings-into-a-text-file
	 * @param newFileName
	 * @param fileText
	 * @param stateChanged
	 * @return stateChanged boolean (fileText is already modified because only the reference was passed in, but stateChanged is not)
	 */
	public static boolean writeFile(String newFileName, ArrayList<String> fileText, boolean stateChanged) {
		FileWriter writer;
		try {
			writer = new FileWriter("/Users/arushi/Desktop/" + newFileName + ".txt");
			tryWriteFile(newFileName, fileText, stateChanged, writer);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(newFileName + " written.");
		stateChanged = false;
		return stateChanged;
	}
	
	private static void tryWriteFile(String newFileName, ArrayList<String> fileText, boolean stateChanged, FileWriter writer) {
		BufferedWriter buffWrite = new BufferedWriter(writer);
		for(String currentLine : fileText) {
			try {
				buffWrite.write(currentLine + System.lineSeparator());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			buffWrite.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static boolean readFile(String fileName, ArrayList<String> fileText, boolean stateChanged) {
		File file = new File("/Users/arushi/Desktop/" + fileName + ".txt"); 
		try {
			FileReader fileReader = new FileReader(file);
			BufferedReader buffRead = new BufferedReader(fileReader); 
			String currentLine = "";
			tryReadFile(currentLine, buffRead, fileText, stateChanged);
			System.out.println("Loaded from file: " + file);
		} catch (FileNotFoundException e) {
			System.out.println("File not found in directory.");
		} 
		return stateChanged;
	}
	
	private static void tryReadFile(String currentLine, BufferedReader buffRead, ArrayList<String> fileText, boolean stateChanged) {
		try { 
			stateChanged = false;
			while((currentLine = buffRead.readLine()) != null) {
				fileText.add(currentLine);
            }
            buffRead.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
	}
}
