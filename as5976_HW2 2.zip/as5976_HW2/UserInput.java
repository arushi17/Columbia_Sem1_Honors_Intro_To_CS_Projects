import java.io.IOException;
import java.util.*;

/**
 * This class handles the calling of Step 1 and Step 2 methods using an overloaded constructor based on user input.
 * It also tests the user input for a few universal invalid cases.
 * @author Arushi Sahai as5976
 *
 */
public class UserInput {

	/**
	 * Overloaded constructor for running the step 1 system.
	 * @param editor1In provides same methods but different implementation from editor2 class.
	 */
	public static void runner(EditorStep1 editor1In) {
		displayCommands();
		do {
			editor1 = editor1In;
			userInput = getUserInput();
			parser = new CommandParser();
			parsedCommand = parser.parseCommands(userInput);
			editor1.performCommand(parsedCommand);
		} while (parsedCommand.getCommandSignifier() != 'q');
		System.out.println("Quitting game.");
	}
	
	/**
	 * Overloaded constructor for running the step 2 system.
	 * @param editor2In provides same methods but different implementation from editor1 class.
	 */
	public static void runner(EditorStep2 editor2In) {
		displayCommands();
		do {
			editor2 = editor2In;
			userInput = getUserInput();
			parser = new CommandParser();
			parsedCommand = parser.parseCommands(userInput);
			editor2.performCommand(parsedCommand);
		} while (parsedCommand.getCommandSignifier() != 'q');
		System.out.println("Quitting game.");
	}
	
	private static void displayCommands() {
		System.out.println("List of command signifiers: \ng : Get file from directory \np : Print entire file to console "
				+ "with line numbers 0 to N+1 \nr : Replace this numbered line with a new line "
				+ "(which could be blank) \ns : Set file contents to directory \nt: Save .cmp file as .txt file \nw: Replace word \nq: Quit");
	}
		
	/**
	 * Uses the console to get a String for the user's input of 'g', 'p', 'r', 's', 't', 'w', or 'q'. 
	 * @return a String of the user's input
	 */
	public static String getUserInput() {
		System.out.println("\nWhat is your command? Enter one of the following: \n'g' + file name (or just 'g' for new file)"
				+ "\n'p' \n'r' + line to be replaced + String that is replacing the line \n's' \n't' \n'w' + word replacing + word to replace \n'q'.");
		String userInput = CONSOLE.nextLine().toLowerCase();
		while(userInputNotValid(userInput)) {
			userInput = CONSOLE.nextLine();
		}
		return userInput;
	}

	private static boolean userInputNotValid(String userInputIn) {
		if(userInputFirstCharSingle(userInputIn)) {
			char userInput = userInputIn.charAt(0);
			if(userInput != 'g' && userInput != 'p' && userInput != 'r' && userInput != 's' && userInput != 't' && userInput != 'w' && userInput != 'q') {
				System.out.println("Please only enter one of the following command signifiers: 'q', 'p', 'r', 's', 't', 'w', or 'q'.");
				return true;
			}
		}
		else {
			System.out.println("Please only enter a single character ('q', 'p', 'r', 's', 't', 'w', or 'q') as the command signifier.");
			return true; 
		}
		return false;
	}
	
	private static boolean userInputFirstCharSingle(String userInput) {
		int firstSpace = userInput.indexOf(' ');
		if (firstSpace == -1 && userInput.length() == 1) {
			return true; // user input is a single character
		}
		else if (firstSpace == 1 && userInput.length() > 2) {
			return true; 
		}
		else {
			return false;
		}
	}
	
	private static String userInput = " ";
	private static CommandParser parser;
	private static Command parsedCommand;
	private static EditorStep1 editor1;
	private static EditorStep2 editor2;
	private static Scanner CONSOLE = new Scanner(System.in);
}
