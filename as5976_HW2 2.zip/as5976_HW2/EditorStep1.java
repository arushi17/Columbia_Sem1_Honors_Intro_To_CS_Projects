import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
import java.util.*;

/**
 * Handles the implementation as described by Step 1 for each of the commands.
 * There are more than 7 methods because there are 6 commands that need implementation, plus their helper methods.
 * Reading and writing helper methods have been moved into the ReadWriteFileStep1 class.
 * @author Arushi Sahai as5976
 *
 */
public class EditorStep1 {
	
	/**
	 * Constructor
	 */
	public EditorStep1() {
		
	}
	
	/**
	 * Calls implementation methods for each command. Method more than 7 lines long because it doesn't logically make sense to break it up.
	 * @param parsedCommand
	 */
	public static void performCommand(Command parsedCommand) {
		switch (parsedCommand.getCommandSignifier()) { 
		case 'g':
			performCommandG(parsedCommand);
			break;
		case 'p':
			performCommandP(parsedCommand);
			break;
		case 'r':
			performCommandR(parsedCommand); 
			break;
		case 's':
			performCommandS(parsedCommand);
			break;
		case 'q':
			performCommandQ(parsedCommand);
			break;
		case 't':
			System.out.println("Command not supported for .txt text editor.");
			break;
		case 'w':
			performCommandW(parsedCommand);
			break;
		default:
			break;
		}
	}
	
	private static void performCommandG(Command parsedCommand) {
		if (stateChanged) {
			System.out.println("Trying to create a new file without saving edits.");
			return;
		}
		
		fileText = new ArrayList<String>();
		stateChanged = ReadWriteFileStep1.readFile(parsedCommand, fileText, stateChanged);
	}
	
	private static void performCommandP(Command parsedCommand) {
		if (fileNotCreated()) {
			return;
		}
		
		ListIterator<String> textIterator = fileText.listIterator(); 
			
		System.out.println("0"); // prints 0th line
		int indexOfLine = 0;
		while (textIterator.hasNext()) {
			indexOfLine++;
			String nextLine = textIterator.next();
			System.out.println((indexOfLine) + " " + nextLine);
		}
		System.out.println(fileText.size() + 1); // prints N+1th line
	}
	
	private static void performCommandR(Command parsedCommand) {
		if (fileNotCreated()) {
			return;
		}
		
		int lineNumber = parsedCommand.getLine() - 1; 
		String text = parsedCommand.getText();
		
		if (lineNumber == fileText.size() && !text.isEmpty()) {
			fileText.add("");
		}
		
		if (text.isEmpty()) {
			textEmptyReplace(lineNumber);
		}
		else {
			textReplace(lineNumber, text);
		}
	}

	private static void performCommandS(Command parsedCommand) {
		if (fileNotCreated()) {
			return;
		}
		String newFileName = parsedCommand.getText();
		
		stateChanged = ReadWriteFileStep1.writeFile(newFileName, fileText, stateChanged);
	}
	
	private static void performCommandQ(Command parsedCommand) {
		if (stateChanged) {
			System.out.println("There are unsaved changes in the editor. Please save with 's' command first.");
			parsedCommand.setCommandSignifier(' '); // so that it doesn't quit
		}
	}
	
	private static void performCommandW(Command parsedCommand) {
		if (fileNotCreated()) {
			return;
		}
		
        String[] paramWords = parsedCommand.getText().split(" ");
        String oldWord = paramWords[0];
        String[] newWords;
        if (paramWords.length > 1) {
            newWords = Arrays.copyOfRange(paramWords, 1, paramWords.length);
        }
        else {
            newWords = new String[0];  // delete oldWord
        }
        System.out.println("Replacing \"" + oldWord + "\" with \"" + String.join(" ", newWords) + "\"");
		replaceWord(oldWord, newWords);
		stateChanged = true;
    }
	
	private static void textEmptyReplace(int lineNumber) {
		try {
			fileText.remove(lineNumber);
			System.out.println("Deleting line " + (lineNumber + 1) + ".");
			stateChanged = true;

		}
		catch (IndexOutOfBoundsException e) {
			System.out.println("Line number does not exist in file.");
		}
	}
	
	private static void textReplace(int lineNumber, String text) {
		try {
			fileText.set(lineNumber, text);
			System.out.println("Replacing line " + (lineNumber + 1) + " with " + text + ".");
			stateChanged = true;
		}
		catch (IndexOutOfBoundsException e) {
			System.out.println("Line number does not exist in file.");
		}
	}
	
	private static void replaceWord(String oldWord, String[] newWords) {
		ListIterator<String> textIterator = fileText.listIterator(); 
		while (textIterator.hasNext()) {
            // split the line so don't accidentally replace parts of words with a simple string replace
			String[] oldLineWords = textIterator.next().split(" ");
            ArrayList<String> newLineWords = new ArrayList<String>();
            for (int i = 0; i < oldLineWords.length; i++) {
                if (oldLineWords[i].equals(oldWord)) {
                    newLineWords.addAll(Arrays.asList(newWords)); // could add nothing
                } else {
                    newLineWords.add(oldLineWords[i]);
                }
            }
            textIterator.set(String.join(" ", newLineWords));
		}
	}
	
	private static boolean fileNotCreated() {
		if (fileText == null) {
			System.out.println("Must create file first using command 'g'.");
			return true;
		}
		return false;
	}
	
	private static ArrayList<String> fileText = null;
	private static boolean stateChanged = false;
	
}

