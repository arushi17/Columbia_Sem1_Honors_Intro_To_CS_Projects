import java.util.*;

public class CommandParser {

	public CommandParser() {
		
	}
	
	/**
	 * Parses a command string to extract the command signifier, line number (if present), and text (if present) -- uses a Command object
	 * Note: string splitting code from https://javarevisited.blogspot.com/2016/10/how-to-split-string-in-java-by-whitespace-or-tabs.html
	 * @param command
	 * @return the parsed command
	 */
	public static Command parseCommands(String command) {
		String[] params = command.split(" ");
		Command parsedCommand = new Command();
		char commandSignifier = params[0].charAt(0);
		parsedCommand.setCommandSignifier(commandSignifier);
		
		switch (commandSignifier) {
		case 'g':
			parseCommandG(parsedCommand, params);
			break;
		case 'p':
			parseCommandP(parsedCommand, params);
			break;
		case 'r':
			parseCommandR(parsedCommand, params);
			break;
		case 's':
			parseCommandS(parsedCommand, params);
			break;
		case 't':
			parseCommandS(parsedCommand, params);
			break;
		case 'w':
			parseCommandW(parsedCommand, params);
			break;
		default:
			parseCommandQ(parsedCommand, params);
		}
		return parsedCommand;
	}
	
	private static void parseCommandG(Command parsedCommand, String[] params) {
		if (params.length > 1) {
			String[] subArray = Arrays.copyOfRange(params, 1, params.length);
			parsedCommand.setText(String.join(" ", subArray));
		}
	}
	
	private static void parseCommandP(Command parsedCommand, String[] params) {
		if (params.length > 1) {
			System.out.println("'p' command can take no parameters.");
			parsedCommand.setCommandSignifier(' ');
		}
	}
	
	private static void parseCommandR(Command parsedCommand, String[] params) {
		if (rCommandInputValid(params)) {		
			try {
				parsedCommand.setLine(Integer.parseInt(params[1]));
			}
			catch (NumberFormatException e) {
				System.out.println("Parameter needed: number of line to be replaced."); 
				parsedCommand.setCommandSignifier(' ');
			}
			if (params.length < 3) {
				parsedCommand.setText("");
			}
			else {
				String[] subArray = Arrays.copyOfRange(params, 2, params.length);
				parsedCommand.setText(String.join(" ", subArray));
			}
		}
	}
	
	private static boolean rCommandInputValid(String[] params) {
		if (params.length == 1) {
			System.out.println("Parameters needed: 'r' + line to be replaced + String that is replacing the line.");
			return false;
		}
		return true;
	}
	
	private static void parseCommandS(Command parsedCommand, String[]params) {
		if (params.length == 1) {
			System.out.println("Parameter needed: name of the file to be saved.");
			parsedCommand.setCommandSignifier(' ');
		}
		else {
			// join all the rest of the strings together -- this is the name of the file to be saved
			String[] subArray = Arrays.copyOfRange(params, 1, params.length);
			parsedCommand.setText(String.join(" ", subArray));
		}
	}
	
	private static void parseCommandW(Command parsedCommand, String[]params) {
		if (params.length == 1) {
			System.out.println("Parameter needed: word to be replaced.");
			parsedCommand.setCommandSignifier(' ');
		}
		
		if (params.length < 2) {
			parsedCommand.setText("");
		}
		else {
			String[] subArray = Arrays.copyOfRange(params, 1, params.length);
			parsedCommand.setText(String.join(" ", subArray));
		}
	}
	
	private static void parseCommandQ(Command parsedCommand, String[] params) {
		if (params.length > 1) {
			System.out.println("'q' command can take no parameters.");
			parsedCommand.setCommandSignifier(' '); // so it doesn't quit
		}
	}
}
