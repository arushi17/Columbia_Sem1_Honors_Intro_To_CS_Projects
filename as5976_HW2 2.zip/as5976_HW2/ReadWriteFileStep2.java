import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ListIterator;

/**
 * Contains helper methods for reading and writing the file in step 2.
 * @author Arushi Sahai as5976
 *
 */
public class ReadWriteFileStep2 {

	/**
	 * Helper method for reading file
	 * @param fileName
	 * @param words
	 * @param findWordIndex
	 * @param countWords
	 * @param fileText
	 */
	public static void readFile(String fileName, ArrayList<String> words, HashMap<String, Integer> findWordIndex, HashMap<String, Integer> countWords, ArrayList<int[]> fileText) {
		if (fileName.isEmpty()) {
			System.out.println("Creating blank file.");
		}
		else {
			File file = new File("/Users/arushi/Desktop/" + fileName + ".cmp");
			try {
				FileReader fileReader = new FileReader(file);
				BufferedReader buffRead = new BufferedReader(fileReader); 
				String currentLine = "";
				readFileTryCatch(buffRead, words, currentLine, findWordIndex, countWords, fileText);
				System.out.println("Loaded from file: " + file); // change this --- USER SHOULD THINK THEYRE OPENING A .TXT FILE
			} catch (FileNotFoundException e) {
				System.out.println("File not found in directory.");
			} 
		}
	}
	
	/**
	 * Helper method for saving files
	 * Note: saving file code from https://stackoverflow.com/questions/6548157/how-to-write-an-arraylist-of-strings-into-a-text-file
	 * @param newFileName
	 * @param words
	 * @param fileText
	 */
	public static void writeFile(String newFileName, ArrayList<String> words, ArrayList<int[]> fileText) {
		FileWriter writer;
		try {
			writer = new FileWriter("/Users/arushi/Desktop/" + newFileName + ".cmp");
			BufferedWriter buffWrite = new BufferedWriter(writer);
		
			// first line with vocabulary of words
			String allWords = String.join(" ", words);
			buffWrite.write(allWords + System.lineSeparator());
					
			// rest of file
			ListIterator<int[]> textIterator = fileText.listIterator();
			while (textIterator.hasNext()) {
				int[] allIndices = textIterator.next();
				String[] allIndicesStr = new String[allIndices.length];
				for (int i = 0; i < allIndices.length; i++) {
					allIndicesStr[i] = Integer.toString(allIndices[i]);
				}
				buffWrite.write(String.join(" ", allIndicesStr) + System.lineSeparator());
			}
			buffWrite.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(newFileName + " written.");
	}
	
	/**
	 * Helper method for writing a .txt file
	 * Note: writing code from https://stackoverflow.com/questions/6548157/how-to-write-an-arraylist-of-strings-into-a-text-file
	 * @param newFileName
	 * @param words
	 * @param fileText
	 */
	public static void writeTextFile(String newFileName, ArrayList<String> words, ArrayList<int[]> fileText) {
		FileWriter writer;
		try {
			writer = new FileWriter("/Users/arushi/Desktop/" + newFileName + ".txt");
			BufferedWriter buffWrite = new BufferedWriter(writer);
			
			// rest of file
			ListIterator<int[]> textIterator = fileText.listIterator();
			while (textIterator.hasNext()) {
				int[] nextLine = textIterator.next();
				String line = "";
				for (int i = 0; i < nextLine.length; i++) {
					String word = words.get(nextLine[i]);
					line = line + word + " ";
				}
				buffWrite.write(line + System.lineSeparator());
			}
			buffWrite.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(newFileName + " written.");
	}
	
	/*
	 * file reading code from https://stackoverflow.com/questions/48961788/reading-a-txt-file-using-bufferedreader-and-filereader?noredirect=1&lq=1
	 */
	private static void readFileTryCatch(BufferedReader buffRead, ArrayList<String> words, String currentLine, HashMap<String, Integer> findWordIndex, HashMap<String, Integer> countWords, ArrayList<int[]> fileText) {
		try { 
			// populate map and arraylist of words from first line
			String firstLine = buffRead.readLine();
			String[] fileWords = firstLine.split(" ");
			for (int i = 0; i < fileWords.length; i++) {
				words.add(fileWords[i]);
				findWordIndex.put(fileWords[i], i);
			}
			
			// populate arraylist of arrays of ints from rest of file
			while((currentLine = buffRead.readLine()) != null) { 
				readFilePopulateArrayList(currentLine, words, findWordIndex, countWords, fileText);
            }
            buffRead.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
	}
	
	private static void readFilePopulateArrayList(String currentLine, ArrayList<String> words, HashMap<String, Integer> findWordIndex, HashMap<String, Integer> countWords, ArrayList<int[]> fileText) {
		String[] lineWords = currentLine.split(" ");
		int[] wordIndices = new int[lineWords.length];
		for (int i = 0; i < lineWords.length; i++) {
			wordIndices[i] = Integer.parseInt(lineWords[i]); // each word represented by an int that corresponds to that particular word
			countWords.put(words.get(wordIndices[i]), countWords.getOrDefault(words.get(wordIndices[i]), 0) + 1); // keeps track of how many times a word is used
		}
		fileText.add(wordIndices);
	}
}
