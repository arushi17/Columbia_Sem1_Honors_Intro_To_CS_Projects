/**
 * This is the class that launches the running of the entire Step 2 system.
 * @author Arushi Sahai as5976
 *
 */
public class RunnerStep2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserInput runProgram = new UserInput();
		EditorStep2 editor2 = new EditorStep2();
		runProgram.runner(editor2);
	}
	
	/**
	 * TESTING: same testing as step 1. Gives the same output for the same commands (disregard that the test file used had different text in it to start off with)
	 * (Scroll through to the bottom to find more than 1 test case) 
	 * 
	 * List of command signifiers: 
g : Get file from directory 
p : Print entire file to console with line numbers 0 to N+1 
r : Replace this numbered line with a new line (which could be blank) 
s : Set file contents to directory 
t: Save .cmp file as .txt file 
w: Replace word 
q: Quit

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
g testcomp
Loaded from file: /Users/arushi/Desktop/testcomp.cmp

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
p
0
1 this is a compressed text file 
2 is is is 
3 this this this 
4 compressed text file 
5

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
r 1 arushi
Replacing line 1 with arushi.

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
p
0
1 arushi 
2 is is is 
3 this this this 
4 compressed text file 
5

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
w arushi compsci

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
p
0
1 compsci 
2 is is is 
3 this this this 
4 compressed text file 
5

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
s arushi
arushi written.

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
p
0
1 compsci 
2 is is is 
3 this this this 
4 compressed text file 
5

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
q
Quitting game.

	 */
	
/** ANOTHER TEST: THE .CMP FILE USED IN TESTING IS CONVERTED TO A .TXT FILE AND THEY ARE PRINTED THE SAME
 * 
 * List of command signifiers: 
g : Get file from directory 
p : Print entire file to console with line numbers 0 to N+1 
r : Replace this numbered line with a new line (which could be blank) 
s : Set file contents to directory 
t: Save .cmp file as .txt file 
w: Replace word 
q: Quit

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
g testcomp
Loaded from file: /Users/arushi/Desktop/testcomp.cmp

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
t
Parameter needed: name of the file to be saved.

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
t arushi
arushi written.

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.




THEN, USING RUNNER 1:

List of command signifiers: 
g : Get file from directory 
p : Print entire file to console with line numbers 0 to N+1 
r : Replace this numbered line with a new line (which could be blank) 
s : Set file contents to directory 
t: Save .cmp file as .txt file 
w: Replace word 
q: Quit

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
g arushi
Loaded from file: /Users/arushi/Desktop/arushi.txt

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
p
0
1 this is a compressed text file 
2 is is is 
3 this this this 
4 compressed text file 
5

What is your command? Enter one of the following: 
'g' + file name (or just 'g' for new file)
'p' 
'r' + line to be replaced + String that is replacing the line 
's' 
't' 
'w' + word replacing + word to replace 
'q'.
q
Quitting game.


THE SIZE OF THIS .TXT FILE IS: 80 bytes. the size of the .cmp file is 64 bytes.
However, the size of a txt file that just says "hi" is 4 bytes, while the corresponding .cmp file is 5 bytes because the contents of the file are so small.

 */
}
