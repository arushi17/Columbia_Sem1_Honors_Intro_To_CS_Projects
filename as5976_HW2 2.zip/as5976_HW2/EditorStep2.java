import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
import java.util.*;

/**
 * Handles the implementation as described by Step 2 for each of the commands.
 * There are more than 7 methods because there are 6 commands that need implementation, plus their helper methods.
 * Reading and writing helper methods have been moved into the ReadWriteFileStep2 class.
 * @author Arushi Sahai as5976
 *
 */
public class EditorStep2 {
	
	/**
	 * Constructor
	 */
	public EditorStep2() {
		
	}
	
	/**
	 * Calls implementation methods for each command. Method more than 7 lines long because it doesn't logically make sense to break it up.
	 * @param parsedCommand
	 */
	public static void performCommand(Command parsedCommand) {
		switch (parsedCommand.getCommandSignifier()) { 
		case 'g':
			performCommandG(parsedCommand);
			break;
		case 'p':
			performCommandP(parsedCommand);
			break;
		case 'r':
			performCommandR(parsedCommand); 
			break;
		case 's':
			performCommandS(parsedCommand);
			break;
		case 'q':
			performCommandQ(parsedCommand);
			break;
		case 't':
			performCommandT(parsedCommand);
			break;
		case 'w':
			performCommandW(parsedCommand);
			break;
		default:
			break;
		}
	}
	
	private static void performCommandG(Command parsedCommand) {
		if (stateChanged) {
			System.out.println("Trying to create a new file without saving edits.");
			return;
		}
		String fileName = parsedCommand.getText();
		resetDataStructures();
		ReadWriteFileStep2.readFile(fileName, words, findWordIndex, countWords, fileText);
	}
	
	private static void performCommandP(Command parsedCommand) {
		if (fileNotCreated()) {
			return;
		}
		
		ListIterator<int[]> textIterator = fileText.listIterator();
		System.out.println("0"); // prints 0th line
		int indexOfLine = 0;
		while (textIterator.hasNext()) {
			indexOfLine++;
			int[] nextLine = textIterator.next();
			String line = "";
			for (int i = 0; i < nextLine.length; i++) {
				String word = words.get(nextLine[i]);
				line = line + word + " ";
			}
			System.out.println((indexOfLine) + " " + line);
		}
		System.out.println(fileText.size() + 1); // prints N+1th line
	}
	
	private static void performCommandR(Command parsedCommand) {
		if (fileNotCreated()) {
			return;
		}
		
		int fileTextIndex = parsedCommand.getLine() - 1; 
		String text = parsedCommand.getText();
		
		if (fileTextIndex == fileText.size()  && !text.isEmpty()) {
			fileText.add(new int[0]); 
		}
		
		int[] fileTextLine;
		
		try {
			fileTextLine = fileText.get(fileTextIndex);
			removeFileTextLine(fileTextLine, fileTextIndex); 
		}
		catch (IndexOutOfBoundsException e) {
			System.out.println("Line number does not exist in file.");
			return;
		}
		
		if (text.isEmpty()) {
			fileText.remove(fileTextIndex);
			System.out.println("Deleting line " + (fileTextIndex + 1) + ".");
		}
		else {
			addTextAtIndex(fileTextIndex, text);
			System.out.println("Replacing line " + (fileTextIndex + 1) + " with " + text + ".");
		}
		stateChanged = true;
	}

	private static void performCommandS(Command parsedCommand) {
		if (fileNotCreated()) {
			return;
		}
		String newFileName = parsedCommand.getText();
		
		ReadWriteFileStep2.writeFile(newFileName, words, fileText);
		stateChanged = false;
	}
	
	private static void performCommandQ(Command parsedCommand) {
		if (stateChanged) {
			System.out.println("There are unsaved changes in the editor. Please save with 's' command first.");
			parsedCommand.setCommandSignifier(' '); // so that it doesn't quit
		}
	}
	
	private static void performCommandT(Command parsedCommand) {
		if (fileNotCreated()) {
			return;
		}
		String newFileName = parsedCommand.getText();
		
		ReadWriteFileStep2.writeTextFile(newFileName, words, fileText);
		stateChanged = false;
	}
	
	/**
	 * SORRY IT'S SO LONG!!!! Didn't break it down but should have.
	 * @param parsedCommand
	 */
	private static void performCommandW(Command parsedCommand) {
		if (fileNotCreated()) {
			return;
		}
		
        String[] paramWords = parsedCommand.getText().split(" ");
        String oldWord = paramWords[0];
        if (!findWordIndex.containsKey(oldWord)) {
            System.out.println("Word does not exist");
            return;
        }

        String[] newWords;
        if (paramWords.length > 1) {
            newWords = Arrays.copyOfRange(paramWords, 1, paramWords.length);
        }
        else {
            newWords = new String[0];  // delete oldWord
        }
        // add newWords to index data structures if they don't already exist
        for (int i = 0; i < newWords.length; i++) {
            if (!findWordIndex.containsKey(newWords[i])) {
            	words.add(newWords[i]);
                findWordIndex.put(newWords[i], words.size() - 1);
				countWords.put(newWords[i], 0);  // don't know how many times it occurs in text
            }
        }
        
        ArrayList<Integer> newWordIndices = new ArrayList<Integer>();
        for (int i = 0; i < newWords.length; i++) {
        	newWordIndices.add(findWordIndex.get(newWords[i]));
        }
        
        // update fileText
		ListIterator<int[]> textIterator = fileText.listIterator();
        int oldWordIndex = findWordIndex.get(oldWord);
		while (textIterator.hasNext()) {
			int[] oldLine = textIterator.next();
			ArrayList<Integer> newLine = new ArrayList<Integer>();
			for (int i = 0; i < oldLine.length; i++) {
			    if (oldLine[i] == oldWordIndex) {
                    newLine.addAll(newWordIndices);
                } else {
                    newLine.add(oldLine[i]);
                }
			}
			int[] newLineInts = new int[newLine.size()];
			for (int i = 0; i < newLine.size(); i++) {
				newLineInts[i] = newLine.get(i);
			}
            fileText.set(fileText.indexOf(oldLine), newLineInts);
        }

		stateChanged = true;
    }
	
	private static void removeFileTextLine(int[] fileTextLine, int fileTextIndex) {
		ArrayList<String> wordsAt0 = new ArrayList<String>();
		for (int i = 0; i < fileTextLine.length; i++) {
			String word = words.get(fileTextLine[i]);
			countWords.put(word, countWords.get(word) - 1);
			if (countWords.get(word) == 0) {
				wordsAt0.add(word);
			}
		}
		
		fileText.set(fileTextIndex, new int[0]);
				
		if (wordsAt0.size() == 0) {
			return;
		}
		ArrayList<String> oldWords = new ArrayList<String>(words);
		for (int i = 0; i < wordsAt0.size(); i++) {
			String word = wordsAt0.get(i);
			countWords.remove(word);
			words.remove(words.indexOf(word));
			findWordIndex.remove(word);
		}
		updateAfterRemoving(oldWords);
	}
	
	private static void updateAfterRemoving(ArrayList<String> oldWords) {
		// full scan and update everything if something was deleted
		for (int j = 0; j < words.size(); j++) {
			findWordIndex.put(words.get(j), j);
		}
		// go and update indices in fileText
		ListIterator<int[]> textIterator = fileText.listIterator();
		while (textIterator.hasNext()) {
			int[] nextLine = textIterator.next();
			for (int i = 0; i < nextLine.length; i++) {
				String oldWord = oldWords.get(nextLine[i]);
				nextLine[i] = findWordIndex.get(oldWord);
			}
		}
	}
	
	private static void addTextAtIndex(int fileTextIndex, String text) {
		String[] lineWords = text.split(" ");
		int[] wordIndices = new int[lineWords.length];
		for (int i = 0; i < lineWords.length; i++) {
			String word = lineWords[i];
			int indexOfWord = words.indexOf(word);
			if (indexOfWord == -1) {
				// word doesn't exist in file yet
				words.add(word); 
				findWordIndex.put(word, words.indexOf(word));
				countWords.put(word, countWords.getOrDefault(word, 0) + 1);					
			}
			else {
				countWords.put(word, countWords.get(word) + 1);
			}
			wordIndices[i] = findWordIndex.get(word);
		}
		fileText.set(fileTextIndex, wordIndices);
	}
	
	private static boolean fileNotCreated() {
		if (fileText == null) {
			System.out.println("Must create file first using command 'g'.");
			return true;
		}
		return false;
	}
	
	private static void resetDataStructures() {
		fileText = new ArrayList<int[]>();
		words = new ArrayList<String>();
		findWordIndex = new HashMap<String, Integer>();
		countWords = new HashMap<String, Integer>();
		stateChanged = false;
	}
	
	private static ArrayList<int[]> fileText = null;
	private static ArrayList<String> words = null;
	private static HashMap<String, Integer> findWordIndex = null;
	private static HashMap<String, Integer> countWords = null; 
	private static boolean stateChanged = false;
	
}

