/**
 * Interface for implementing the Strategy pattern for terminal observation behaviors
 * @author Arushi Sahai as5976
 *
 */
public interface TerminalBehavior {
	
	/**
	 * implementation of the behavior
	 * @param currentRecord array of data of each field of record
	 * @param terminalFieldName what field name to terminate on
	 */
	public void observeRecord(FieldData[] currentRecord, String terminalFieldName);
	
	/**
	 * @return result of terminate observation
	 */
	public String terminateAndGetStats();

}
