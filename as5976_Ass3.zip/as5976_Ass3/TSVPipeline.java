import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Contains all implementation of the pipeline as specified in Runner
 * @author Arushi Sahai as5976
 *
 */
public class TSVPipeline {
	
	/**
	 * Constructor. Contains logic for determining which Terminal Observation command to do
	 * @param myTSVFilter
	 */
	public TSVPipeline (TSVFilter myTSVFilter) {
		this.myTSVFilter = myTSVFilter;
		if (myTSVFilter.getTerminalObservationOperation() != null) {
			if (myTSVFilter.getTerminalObservationOperation() == TerminalObservation.COUNT) {
				terminalBehavior = new CountBehavior();
			}
			else if (myTSVFilter.getTerminalObservationOperation() == TerminalObservation.MIN) {
				terminalBehavior = new MinBehavior();
			}
			else if (myTSVFilter.getTerminalObservationOperation() == TerminalObservation.MAX) {
				terminalBehavior = new MaxBehavior();
			}
			else if (myTSVFilter.getTerminalObservationOperation() == TerminalObservation.ISSAME) {
				terminalBehavior = new IsSameBehavior();
			}
			else if (myTSVFilter.getTerminalObservationOperation() == TerminalObservation.ISSORTED) {
				terminalBehavior = new IsSortedBehavior();
			}
		}
	}
	
	/**
	 * Starts the processing of the TSV file
	 */
	public void doit() {
		processTSVFile(myTSVFilter.getInputFileName(), myTSVFilter.getOutputFileName());
	}

	private void processTSVFile(String inputFileName, String outputFileName) {
		File file = new File("/Users/arushi/Desktop/" + inputFileName + ".tsv");
		try {
			FileReader fileReader = new FileReader(file);
			BufferedReader buffRead = new BufferedReader(fileReader);
			System.out.println("File found: " + file);
			
			FileWriter writer;
			String outputFile = "/Users/arushi/Desktop/" + outputFileName + ".tsv";
			writer = new FileWriter(outputFile);
			BufferedWriter buffWrite = new BufferedWriter(writer);
			processTSVLines(buffRead, buffWrite, outputFile);
			
            buffRead.close();
			buffWrite.close();
		} catch (IOException e) {
			System.out.println("File not found in directory.");
		} 
	}
	
	private void processTSVLines(BufferedReader buffRead, BufferedWriter buffWrite, String outputFile) {
		try { 
			String firstLine = buffRead.readLine();
			if (!processTSVFirstLine(firstLine)) {
				return;
			}
			
			String secondLine = buffRead.readLine();
			if (!processTSVSecondLine(secondLine)) {
				return;
			}
			
			if (!isFilterValid() || !isTerminalValid()) {
				return;
			}
			
			buffWrite.write(firstLine + System.lineSeparator());
			buffWrite.write(secondLine + System.lineSeparator());
			
			// records:
			String currentRecordString = "";
			FieldData[] currentRecord;
			while((currentRecordString = buffRead.readLine()) != null) { 				
				currentRecord = new FieldData[recordNumFields];
				if (parseAndShouldOutputRecord(currentRecordString, currentRecord)) {
					buffWrite.write(currentRecordString + System.lineSeparator());
					if (terminalBehavior != null) {
						terminalBehavior.observeRecord(currentRecord, myTSVFilter.getTerminalFieldName());
					}
				}
            }
			System.out.println("File written: " + outputFile);
			
			if (terminalBehavior != null) {
				System.out.println(terminalBehavior.terminateAndGetStats());
			}
        }
        catch(IOException e){
            e.printStackTrace();
        }
	}
	
	private boolean processTSVFirstLine(String firstLine) {
		fieldNames = firstLine.split("\t");
		recordNumFields = fieldNames.length;
		if (recordNumFields == 0) {
			System.out.println("Error: Empty header.");
			return false;
		}
		System.out.println("First line found.");
		for (int i = 0; i < fieldNames.length; i++) {
			if (fieldNames[i].isEmpty()) {
				System.out.println("Error: Empty header element.");
				return false;
			}
		}
		//printLineForTesting(fieldNames); // TESTING
		return true;
	}
	
	private boolean processTSVSecondLine(String secondLine) {
		fieldTypes = secondLine.split("\t");
		
		// check for matching length
		if (fieldTypes.length != recordNumFields) {
			System.out.println("Error: Header lengths do not match.");
			return false; // does not go into the while loop that reads the records
		}
		
		// check if it's only made up of Strings or longs
		for (int i = 0; i < fieldTypes.length; i++) {
			if (!fieldTypes[i].equals("String") && !fieldTypes[i].equals("long")) {
				System.out.println("Field types of element " + i + " not "
						+ "specified in terms of 'String' and 'long' only.");
				return false;
			}
		}
		
		System.out.println("Second line found.");
		//printLineForTesting(fieldTypes); // TESTING
		return true;
	}
	
	private void processTSVRecords() {
		
	}
	
	private boolean isFilterValid() {
		if (myTSVFilter.getSelectFieldName().equals("")) {
			return true;
		}
		for (int i = 0; i < fieldNames.length; i++) {
			if (myTSVFilter.getSelectFieldName().equals(fieldNames[i])) {
				if (fieldTypes[i].equals("String") && !myTSVFilter.getFieldValueString().equals("")) {
					return true;
				}
				else if (fieldTypes[i].equals("long") && myTSVFilter.getFieldValueLong() != null) {
					return true;
				}
				else {
					System.out.println("Field type given in filter does not match type of field in header.");
					return false;
				}
			}
		}
		System.out.println("Filter name does not exist in header.");
		return false;
	}
	
	private boolean isTerminalValid() {
		if (terminalBehavior == null) {
			return true;
		}
		for (int i = 0; i < fieldNames.length; i++) {
			if (myTSVFilter.getTerminalFieldName().equals(fieldNames[i])) {
				return true;
			}
		}
		System.out.println("Terminal operation name does not exist in header.");
		return false;
	}
	
	private void printLineForTesting(String[] line) {
		System.out.println("\nTESTING: printing line elements");
		for (int i = 0; i < line.length; i++) {
			System.out.println(line[i]);
		}
		System.out.println();
	}
	
	private boolean parseAndShouldOutputRecord(String currentRecordString, FieldData[] currentRecord) {
		String[] recordFields = currentRecordString.split("\t");
		if (recordFields.length != recordNumFields) {
			System.out.println("Omitting record from output: Record length "
					+ "does not match designated record length.");
			return false; // avoids null pointer exceptions later on
		}
		//printLineForTesting(recordFields); // TESTING
		
		return !parseAndShouldExcludeRecord(recordFields, currentRecord);
	}
	
	private boolean parseAndShouldExcludeRecord(String[] recordFields, FieldData[] currentRecord) {
		boolean mustExclude = false;
		for (int i = 0; i < recordFields.length; i++) {
			currentRecord[i] = new FieldData();
			currentRecord[i].setFieldName(fieldNames[i]);
			currentRecord[i].setFieldType(fieldTypes[i]);
			if (fieldTypes[i].equals("long")) {
				mustExclude = parseAndShouldExcludeOnLongField(fieldNames[i], recordFields[i], i, currentRecord[i]);
			}
			else {
				mustExclude = parseAndShouldExcludeOnStringField(fieldNames[i], recordFields[i], currentRecord[i]);
			}
			if (mustExclude) {
				//System.out.println("Excluding on " + fieldNames[i] + "\n");
				return true;
			}
		}
		return false;
	}
	
	private boolean parseAndShouldExcludeOnStringField(String fieldName, String fieldValue, FieldData fieldData) {
		fieldData.setFieldValueString(fieldValue);
		if (!myTSVFilter.getSelectFieldName().equals(fieldName)) {
			return false;
		}
		if (!myTSVFilter.getFieldValueString().equals(fieldValue)) {
			return true;
		}
		return false;
	}
	
	private boolean parseAndShouldExcludeOnLongField(String fieldName, String fieldValue, int i, FieldData fieldData) {
		long fieldValueLong;
		try {
			fieldValueLong = Long.parseLong(fieldValue, 10);
			fieldData.setFieldValueLong(fieldValueLong);
		}
		catch(NumberFormatException e) {
			// if can't be converted but should have been able to convert
			System.out.println("Omitting record from output: Record "
					+ "field type of element " + i + " does not match "
							+ "designated field type.");
			return true;
		}
		if (myTSVFilter.getFieldValueLong() != null) {
			if (!myTSVFilter.getSelectFieldName().equals(fieldName)) {
				return false;
			}
			if (myTSVFilter.getFieldValueLong() == fieldValueLong) {
				return false;
			}
			return true;
		}
		return false;
	}
	
	private TSVFilter myTSVFilter;
	private String[] fieldNames;
	private String[] fieldTypes;
	private int recordNumFields;
	private TerminalBehavior terminalBehavior = null;
	
}
