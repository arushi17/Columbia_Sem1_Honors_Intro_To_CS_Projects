/**
 * Stores data about each individual field in a particular record. 
 * Used by TerminalBehavior Strategy pattern.
 * @author Arushi Sahai as5976
 *
 */
public class FieldData {
	
	/**
	 * Empty constructor
	 */
	public FieldData() {
		
	}
	
	/**
	 * Getter method
	 * @return fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}
	
	/**
	 * Getter method
	 * @return fieldType
	 */
	public String getFieldType() {
		return fieldType;
	}
	
	/**
	 * Getter method
	 * @return fieldValueString
	 */
	public String getFieldValueString() {
		return fieldValueString;
	}
	
	/**
	 * Getter method
	 * @return fieldValueLong
	 */
	public Long getFieldValueLong() {
		return fieldValueLong;
	}
	
	/**
	 * Setter method
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	/**
	 * Setter method
	 */
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	
	/**
	 * Setter method
	 */
	public void setFieldValueString(String fieldValueString) {
		this.fieldValueString = fieldValueString;
	}
	
	/**
	 * Setter method
	 */
	public void setFieldValueLong(Long fieldValueLong) {
		this.fieldValueLong = fieldValueLong;
	}
	
	private String fieldName = null;
	private String fieldType = null;
	private String fieldValueString = null;
	private Long fieldValueLong = null;
}
