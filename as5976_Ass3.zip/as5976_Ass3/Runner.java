/**
 * This is the Runner for a pipeline program for TSV files. The system assumes
 * that all data are just Strings or longs. The minimum format is that each 
 * header line should have at least one element. The program allows the user
 * to specify a filter according to the optional .select() method. It also
 * allows the user to get some data of the whole stream using the .terminate()
 * method. The result of the pipeline is another TSV file. The two files can be
 * checked against one another using the following Terminal command:
 * "diff --strip-trailing-cr sampletsv.tsv sampletsvoutput.tsv" to ignore the
 * two different kinds of "new lines."
 * 
 * @author Arushi Sahai as5976
 *
 */
public class Runner {

	public static void main(String[] args) {
		TSVFilter myTSVFilter = new TSVFilter
				.WhichFile("sampletsv", "sampletsvoutput2")
				.select("Name", "Frank")
				//.terminate("Age", TerminalObservation.MIN)
				.done();
		System.out.println(myTSVFilter); // TESTING
		new TSVPipeline(myTSVFilter).doit();
	}
}

/**
 * * Sample output: SEE INPUT AND OUTPUT FILE INCLUDED IN SUBMISSION
 * 
 * Runner:
 * 
 * public static void main(String[] args) {
		TSVFilter myTSVFilter = new TSVFilter
				.WhichFile("sampletsv", "sampletsvoutput2")
				.select("Name", "Frank")
				//.terminate("Age", TerminalObservation.MIN)
				.done();
		System.out.println(myTSVFilter); // TESTING
		new TSVPipeline(myTSVFilter).doit();
	}
	
 * Console:
 * 
 * TSVFilter: 
inputFileName: sampletsv
outputFileName: sampletsvoutput2
selectFieldName: Name
select fieldValueString: Frank

File found: /Users/arushi/Desktop/sampletsv.tsv
First line found.
Second line found.
File written: /Users/arushi/Desktop/sampletsvoutput2.tsv
 * 
 * 
 * Sample output 2: 
 * 
 * Runner:
 * 
 * public static void main(String[] args) {
		TSVFilter myTSVFilter = new TSVFilter
				.WhichFile("sampletsv", "sampletsvoutput2")
				.select("Name", "Frank")
				.terminate("Name", TerminalObservation.ISSORTED)
				.done();
		System.out.println(myTSVFilter); // TESTING
		new TSVPipeline(myTSVFilter).doit();
	}
 * 
 * Console:
 * 
 * TSVFilter: 
inputFileName: sampletsv
outputFileName: sampletsvoutput2
selectFieldName: Name
select fieldValueString: Frank
terminalOperation: ISSORTED

File found: /Users/arushi/Desktop/sampletsv.tsv
First line found.
Second line found.
File written: /Users/arushi/Desktop/sampletsvoutput2.tsv

isSorted: no

 *
 *
 * Sample output 3:
 * 
 * Runner:
 * 
 * public static void main(String[] args) {
		TSVFilter myTSVFilter = new TSVFilter
				.WhichFile("sampletsv", "sampletsvoutput2")
				//.select("Name", "Frank")
				.terminate("Age", TerminalObservation.MIN)
				.done();
		System.out.println(myTSVFilter); // TESTING
		new TSVPipeline(myTSVFilter).doit();
	}
 * 
 * Console:
 * 
 * TSVFilter: 
inputFileName: sampletsv
outputFileName: sampletsvoutput2
selectFieldName: 
select fieldValueString: 
terminalOperation: MIN

File found: /Users/arushi/Desktop/sampletsv.tsv
First line found.
Second line found.
File written: /Users/arushi/Desktop/sampletsvoutput2.tsv

Min: 18

 *
 */

