/**
 * Implements TerminalBehavior interface, provides implementation for 
 * TerminalObervation.MAX selection.
 * @author Arushi Sahai as5976
 *
 */
public class MaxBehavior implements TerminalBehavior {

	@Override
	/**
	 * Provides implementation for finding the max, separated on Strings and longs
	 */
	public void observeRecord(FieldData[] currentRecord, String terminalFieldName) {
		for (int i = 0; i < currentRecord.length; i++) {
			FieldData currentField = currentRecord[i];
			if (currentField.getFieldName().equals(terminalFieldName)) {
				if (currentField.getFieldType().equals("String")) {
					observeRecordString(currentField);
				}
				else {
					observeRecordLong(currentField);
				}
				return;
			}
		}
	}
	
	private void observeRecordString(FieldData currentField) {
		if (maxString == null) {
			maxString = currentField.getFieldValueString();
		}
		else if (currentField.getFieldValueString().compareTo(maxString) > 0) {
				maxString = currentField.getFieldValueString();
		}
	}
	
	private void observeRecordLong(FieldData currentField) {
		if(maxLong == null) {
			maxLong = currentField.getFieldValueLong();
		}
		else if (currentField.getFieldValueLong() > maxLong) {
			maxLong = currentField.getFieldValueLong();
		}
	}

	@Override
	/**
	 * returns the max
	 */
	public String terminateAndGetStats() {
		if (maxLong != null) {
			return "\nMax: " + maxLong;
		}
		else {
			return "\nMax: " + maxString; 
		}
	}
	
	private Long maxLong = null;
	private String maxString = null;

}