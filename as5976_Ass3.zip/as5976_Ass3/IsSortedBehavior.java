/**
 * Implements TerminalBehavior interface, provides implementation for 
 * TerminalObervation.ISSORTED selection.
 * @author Arushi Sahai as5976
 *
 */
public class IsSortedBehavior implements TerminalBehavior {

	@Override
	/**
	 * Provides implementation for finding the max, separated on Strings and longs
	 */
	public void observeRecord(FieldData[] currentRecord, String terminalFieldName) {
		for (int i = 0; i < currentRecord.length; i++) {
			FieldData currentField = currentRecord[i];
			if (currentField.getFieldName().equals(terminalFieldName)) {
				if (currentField.getFieldType().equals("String")) {
					observeRecordString(currentField);
				}
				else {
					observeRecordLong(currentField);
				}
				return;
			}
		}
	}
	
	private void observeRecordString(FieldData currentField) {
		if (firstString == null) {
			firstString = currentField.getFieldValueString();
		}
		else if (secondString == null) {
			secondString = currentField.getFieldValueString();
		}
		else if (secondString.compareTo(firstString) > 0) {
			isSortedAscending = true;
			if (currentField.getFieldValueString().compareTo(firstString) < 0) {
				isSortedAscending = false;
			}
		}
		else if (secondString.compareTo(firstString) < 0) {
			isSortedDescending = true;
			if (currentField.getFieldValueString().compareTo(firstString) > 0) {
				isSortedDescending = false;
			}
		}
	}
	
	private void observeRecordLong(FieldData currentField) {
		if(firstLong == null) {
			firstLong = currentField.getFieldValueLong();
		}
		else if (secondLong == null) {
			secondLong = currentField.getFieldValueLong();
		}
		else if (secondLong > firstLong) {
			isSortedAscending = true;
			if (currentField.getFieldValueLong() < firstLong) {
				isSortedAscending = false;
			}
		}
		else if (secondLong < firstLong) {
			isSortedDescending = true;
			if (currentField.getFieldValueLong() > firstLong) {
				isSortedDescending = false;
			}
		}
	}

	@Override
	/**
	 * returns ascending, descending, or no if isn't sorted
	 */
	public String terminateAndGetStats() {
		if (isSortedAscending) {
			return "\nisSorted: ascending";
		}
		else if (isSortedDescending) {
			return "\nisSorted: descending";
		}
		else {
			return "\nisSorted: no";
		}
	}
	
	private boolean isSortedAscending = false;
	private boolean isSortedDescending = false;
	private String firstString = null;
	private String secondString = null;
	private Long firstLong = null;
	private Long secondLong = null;

}