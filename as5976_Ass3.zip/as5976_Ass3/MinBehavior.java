/**
 * Implements TerminalBehavior interface, provides implementation for 
 * TerminalObervation.MIN selection.
 * @author Arushi Sahai as5976
 *
 */
public class MinBehavior implements TerminalBehavior {

	@Override
	/**
	 * Provides implementation for finding the min, separated on Strings and longs
	 */
	public void observeRecord(FieldData[] currentRecord, String terminalFieldName) {
		for (int i = 0; i < currentRecord.length; i++) {
			FieldData currentField = currentRecord[i];
			if (currentField.getFieldName().equals(terminalFieldName)) {
				if (currentField.getFieldType().equals("String")) {
					observeRecordString(currentField);
				}
				else {
					observeRecordLong(currentField);
				}
				return;
			}
		}
	}
	
	private void observeRecordString(FieldData currentField) {
		if (minString == null) {
			minString = currentField.getFieldValueString();
		}
		else if (currentField.getFieldValueString().compareTo(minString) < 0) {
				minString = currentField.getFieldValueString();
		}
	}
	
	private void observeRecordLong(FieldData currentField) {
		if(minLong == null) {
			minLong = currentField.getFieldValueLong();
		}
		else if (currentField.getFieldValueLong() < minLong) {
			minLong = currentField.getFieldValueLong();
		}
	}

	@Override
	/**
	 * returns min
	 */
	public String terminateAndGetStats() {
		if (minLong != null) {
			return "\nMin: " + minLong;
		}
		else {
			return "\nMin: " + minString; 
		}
	}
	
	private Long minLong = null;
	private String minString = null;

}