/**
 * Implements TerminalBehavior interface, provides implementation for 
 * TerminalObervation.ISSAME selection.
 * @author Arushi Sahai as5976
 *
 */
public class IsSameBehavior implements TerminalBehavior {

	@Override
	/**
	 * Provides implementation for finding the max, separated on Strings and longs
	 */
	public void observeRecord(FieldData[] currentRecord, String terminalFieldName) {
		for (int i = 0; i < currentRecord.length; i++) {
			FieldData currentField = currentRecord[i];
			if (currentField.getFieldName().equals(terminalFieldName)) {
				if (currentField.getFieldType().equals("String")) {
					observeRecordString(currentField);
				}
				else {
					observeRecordLong(currentField);
				}
				return;
			}
		}
	}
	
	private void observeRecordString(FieldData currentField) {
		if (firstString == null) {
			firstString = currentField.getFieldValueString();
		}
		else if (currentField.getFieldValueString().compareTo(firstString) != 0) {
			isSame = false;
		}
	}
	
	private void observeRecordLong(FieldData currentField) {
		if(firstLong == null) {
			firstLong = currentField.getFieldValueLong();
		}
		else if (currentField.getFieldValueLong() != firstLong) {
			isSame = false;
		}
	}

	@Override
	/**
	 * returns true if same, false if not
	 */
	public String terminateAndGetStats() {
		if (isSame == false) {
			return "\nisSame: false";
		}
		else {
			return "\nisSame: true"; 
		}
	}
	
	private boolean isSame = true;
	private String firstString = null;
	private Long firstLong = null;

}