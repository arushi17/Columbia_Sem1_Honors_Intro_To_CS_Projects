/**
 * Enum for specifying Terminal Observation
 * @author Arushi Sahai as5976
 *
 */
public enum TerminalObservation {
	COUNT, MIN, MAX, ISSAME, ISSORTED
}
