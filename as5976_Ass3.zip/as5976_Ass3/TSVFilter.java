/**
 * Contains fields that can be specified by the user.
 * Uses the Builder pattern.
 * @author Arushi Sahai
 *
 */
public class TSVFilter {

	private TSVFilter(WhichFile whichFileName) {
		this.inputFileName = whichFileName.inputFileName;
		this.outputFileName = whichFileName.outputFileName;
		this.selectFieldName = whichFileName.selectFieldName;
		this.fieldValueString = whichFileName.fieldValueString;
		this.fieldValueLong = whichFileName.fieldValueLong;
		this.terminalFieldName = whichFileName.terminalFieldName;
		this.operation = whichFileName.operation;
	}
	
	/**
	 * Getter
	 * @return inputFileName
	 */
	public String getInputFileName() {
		return inputFileName;
	}
	
	/**
	 * Getter
	 * @return outputFileName
	 */
	public String getOutputFileName() {
		return outputFileName;
	}
	
	/**
	 * Getter
	 * @return selectFieldName
	 */
	public String getSelectFieldName() {
		return selectFieldName;
	}
	
	
	/**
	 * Getter
	 * @return fieldValueString
	 */
	public String getFieldValueString() {
		return fieldValueString;
	}
	
	/**
	 * Getter
	 * @return fieldValueLong
	 */
	public Long getFieldValueLong() {
		return fieldValueLong;
	}
	
	/**
	 * Getter
	 * @return terminalFieldName
	 */
	public String getTerminalFieldName() {
		return terminalFieldName;
	}
	
	/**
	 * Getter
	 * @return TerminalObservation operation
	 */
	public TerminalObservation getTerminalObservationOperation() {
		return operation;
	}
	
	@Override
	/**
	 * Prints all specified fields
	 */
	public String toString() {
		String returnString = "TSVFilter: \n" 
				+ "inputFileName: " + inputFileName + "\n"
				+ "outputFileName: " + outputFileName + "\n"
				+ "selectFieldName: " + selectFieldName + "\n";
		if (fieldValueLong == null) {
			returnString += "select fieldValueString: " + fieldValueString + "\n";
		}
		else {
			returnString += "select fieldValueLong: " + fieldValueLong + "\n";
		}
		if (operation != null) {
			returnString += "terminalOperation: " + operation + "\n";
		}
		return returnString;
	}
	
	/**
	 * Implements Builder pattern for TSVFilter class
	 * @author Arushi Sahai as5976
	 *
	 */
	public static class WhichFile {
		
		/**
		 * Constructor
		 * @param inputFileName
		 * @param outputFileName
		 */
		public WhichFile(String inputFileName, String outputFileName) {
			this.inputFileName = inputFileName;
			this.outputFileName = outputFileName;
		}
		
		/**
		 * Optional, specifies filter with String
		 * @param selectFieldName
		 * @param fieldValue
		 * @return WhichFile object itself
		 */
		public WhichFile select(String selectFieldName, String fieldValue) {
			this.selectFieldName = selectFieldName;
			this.fieldValueString = fieldValue;
			return this;
		}
		
		/**
		 * Optional, specifies filter with long
		 * @param selectFieldName
		 * @param fieldValue
		 * @return WhichFile object itself
		 */
		public WhichFile select(String selectFieldName, long fieldValue) {
			this.selectFieldName = selectFieldName;
			this.fieldValueLong = new Long(fieldValue);
			return this;
		}
		
		/**
		 * Optional, specifies terminal command
		 * @param terminalFieldName
		 * @param operation
		 * @return WhichFile object itself
		 */
		public WhichFile terminate(String terminalFieldName, TerminalObservation operation) {
			this.terminalFieldName = terminalFieldName;
			this.operation = operation;
			return this;
		}
		
		/**
		 * Finishes Builder pattern
		 * @return a TSVObject
		 */
		public TSVFilter done() {
			return new TSVFilter(this);
		}
		
		private final String inputFileName, outputFileName;
		private String selectFieldName = "", terminalFieldName = "", fieldValueString = "";	
		private Long fieldValueLong = null;
		private TerminalObservation operation;
	}
	
	private final String inputFileName, outputFileName, selectFieldName, terminalFieldName;
	private String fieldValueString = null;
	private Long fieldValueLong = null;
	private TerminalObservation operation = null;
}
