/**
 * Implements TerminalBehavior interface, provides implementation for 
 * TerminalObervation.COUNT selection.
 * @author Arushi Sahai as5976
 *
 */
public class CountBehavior implements TerminalBehavior {

	@Override
	/**
	 * Provides implementation for counting
	 */
	public void observeRecord(FieldData[] currentRecord, String terminalFieldName) {
		count++;
	}

	@Override
	/**
	 * returns the count
	 */
	public String terminateAndGetStats() {
		return "\nCount: " + count;
	}
	
	private int count = 0;

}
