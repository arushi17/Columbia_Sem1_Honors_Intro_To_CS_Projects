import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

/**
 * Holds methods for drawing Exhaust ellipses of an individual Car
 * @author Arushi Sahai as5976
 *
 */
public class Exhaust {

	/**
	 * Exhaust constructor, also sets variables that make sure ellipses are drawn at a reasonable interval
	 * @param maxEllipseSize
	 * @param minEllipseSize
	 * @param numMaxExhaust
	 */
	public Exhaust(double maxEllipseSize, double minEllipseSize, int numMaxExhaust ) {
		this.maxEllipseSize = maxEllipseSize;
		this.minEllipseSize = minEllipseSize;
		exhaustQueue = new LinkedList<Ellipse2D.Double>();
		this.numExhaust = numMaxExhaust;
		this.drawEveryN = (maxEllipseSize - minEllipseSize) / 2;
		drawCount = 0;
	}
	
	/**
	 * Draws ellipses, also keeps track of the ellipses in a queue so they disappear eventually
	 * @param g2D
	 * @param x
	 * @param y
	 */
	public void draw(Graphics2D g2D, int x, int y) {
		if (drawCount > drawEveryN) {
			double exhaustSizeX = Math.random() * (maxEllipseSize - minEllipseSize) + minEllipseSize;
			double exhaustSizeY = Math.random() * (maxEllipseSize - minEllipseSize) + minEllipseSize;
			exhaustQueue.add(new Ellipse2D.Double(x, y, exhaustSizeX, exhaustSizeY));
			if (exhaustQueue.size() > numExhaust) {
				exhaustQueue.remove();
			}
			drawCount = 0;
		}
		for (Ellipse2D.Double exhaust : exhaustQueue) {
			g2D.fill(exhaust);
		}
		drawCount++;
	}
	
	private double maxEllipseSize;
	private double minEllipseSize;
	private Queue<Ellipse2D.Double> exhaustQueue; 
	private int numExhaust;
	private double drawEveryN;
	private int drawCount;
}
