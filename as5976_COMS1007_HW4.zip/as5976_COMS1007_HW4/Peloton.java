import java.awt.*;
import java.awt.geom.*;
import java.util.ArrayList;
/**
 * Code derived from Box class on Courseworks (@author John Kender)
 * @author Arushi Sahai as5976
 *
 */

/**
 * Peloton is a group of Cars, implemented using Composite pattern
 * @author arushi
 *
 */
public class Peloton implements MovingObject {
	
	/**
	 * Peloton constructor, keeps track of Cars in an ArrayList
	 */
	public Peloton() {
		carsToDraw = new ArrayList<Car>();
	}
	
	/**
	 * Implements MovingObject
	 */
	public void translate(int xChange, int yChange) {
		for (int i = 0; i < carsToDraw.size(); i++) {
			carsToDraw.get(i).translate(xChange, yChange);
		}
	}
	
	/**
	 * Runner adds the peloton objects in the right order
	 * @param addCar
	 */
	public void add(Car addCar) {
		for (int i = 0; i < carsToDraw.size(); i++) {
			if (carsToDraw.get(i).getUnit() > addCar.getUnit()) {
				carsToDraw.add(i, addCar);
			}
		}
		if (!carsToDraw.contains(addCar)) {
			carsToDraw.add(addCar);

		}
	}
	
	/**
	 * Draws the Peloton
	 */
	public void draw(Graphics2D g2D) {
		// draw the figure
		for (int i = 0; i < carsToDraw.size(); i++) {
			carsToDraw.get(i).draw(g2D);
		}
	}
	
	private ArrayList<Car> carsToDraw;
}
