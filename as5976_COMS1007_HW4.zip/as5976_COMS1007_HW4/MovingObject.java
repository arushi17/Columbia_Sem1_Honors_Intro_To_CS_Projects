import java.awt.Graphics;
import java.awt.Graphics2D;

/**
 * MovingObject interface
 * Source of code: courseworks (@author John Kender)
 * @author Arushi Sahai as5976
 * 
 */
public interface MovingObject {
	void draw(Graphics2D g2D);
	void translate(int xChange, int yChange);
}
