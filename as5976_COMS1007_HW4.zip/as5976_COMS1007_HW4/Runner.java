import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Runner class that creates a Peloton of Cars and draws them
 * Has the ability to control the Peloton speed using a slider
 * @author Arushi Sahai as5976
 *
 */
public class Runner {
	
	/**
	 * Main method, creates the Peloton and draws it on a timer using JFrame
	 * Code from class, @author John Kender
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame myFrame = new JFrame();
				
		Peloton peloton = generatePeloton();
		pelotonSpeed = 3;
					
		final MyIcon myIcon = new MyIcon(peloton, ICON_W, ICON_H);
		final JLabel myLabel = new JLabel(myIcon);
		myFrame.add(myLabel);
			
		myFrame.setLayout(new FlowLayout());

		myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myFrame = generateSlider(myFrame);
		myFrame.pack();
		myFrame.setVisible(true);
			
		final int DELAY = 100;
		// Milliseconds between timer ticks
		Timer myTimer = new Timer(DELAY, new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				peloton.translate(pelotonSpeed, 0);
				myLabel.repaint();
			}
		});
		myTimer.start();		
	}
	
	private static Peloton generatePeloton() {
		Peloton peloton = new Peloton();
		int maxYPos = (int) (ICON_H - UNIT * MAX_CAR_SCALE * Car.getCarHeight());
		Random random = new Random();
		int numCars = random.nextInt(MAX_NUM_CARS - MIN_NUM_CARS) + MIN_NUM_CARS;
		
		int minYPos = (int) (Car.getCarHeight() * UNIT);
		int yPosIncrement = (maxYPos - minYPos) / numCars;
		int yPos = minYPos;
		Car car;
		for (int i = 0; i < numCars; i++) {
			double yPosScale = random.nextDouble() * 0.4 + 0.8;
			yPos *= yPosScale;
			yPos = Math.min(maxYPos, Math.max(yPos, minYPos));
			double carScale = getCarScale(yPos, maxYPos);
			car = new Car(X_POS_RACE_START, yPos, carScale * UNIT);
			peloton.add(car);
			yPos += yPosIncrement;
		}
		return peloton;
	}
	
	private static JFrame generateSlider(JFrame myFrame) {
		JPanel panel = new JPanel();
		JLabel status = new JLabel("Slider for speed of peleton", JLabel.CENTER);
		
		JSlider slider = new JSlider(MIN_SPEED, MAX_SPEED, 1);
		slider.setMinorTickSpacing(5);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		
		// Source code from https://examples.javacodegeeks.com/desktop-java/swing/java-swing-slider-example/
		Hashtable<Integer, JLabel> position = new Hashtable<Integer, JLabel>();
        position.put(MIN_SPEED, new JLabel(MIN_SPEED.toString()));
        position.put(MAX_SPEED, new JLabel(MAX_SPEED.toString()));
        position.put(MIN_SPEED / 2, new JLabel(new Integer(MIN_SPEED / 2).toString()));
        position.put(MAX_SPEED / 2, new JLabel(new Integer(MAX_SPEED / 2).toString()));
        position.put(MAX_SPEED + MIN_SPEED, new JLabel(new Integer(MAX_SPEED + MIN_SPEED).toString()));
         
        slider.setLabelTable(position);
		
		slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                status.setText("Speed of peloton: " + ((JSlider)e.getSource()).getValue());
                pelotonSpeed = ((JSlider)e.getSource()).getValue();
            }
        });
		
		panel.add(slider);
		myFrame.add(panel);
		myFrame.add(status);
		
		return myFrame;
	}
	
	// fits a linear function where scale = 0.5 when yPos = 0 and scale = 2.0 when yPos approaches ICON_H
	// adds a small random-sized variation on top of this
	private static double getCarScale(int yPos, int maxYPos) {
		Random rand = new Random();
		double scale = (MAX_CAR_SCALE - MIN_CAR_SCALE) / maxYPos * yPos + MIN_CAR_SCALE;
		scale = scale * (rand.nextDouble() * 0.4 + 0.8); // +/- 20% wriggle room
		return Math.min(MAX_CAR_SCALE, Math.max(MIN_CAR_SCALE, scale));
	}
	
	private static final int ICON_W = 600;
	private static final int ICON_H = 600;
	private static final int X_POS_RACE_START = 70;
	private static final int UNIT = 10;
	private static final int MIN_NUM_CARS = 3;
	private static final int MAX_NUM_CARS = 7;
	private static final double MIN_CAR_SCALE = 0.5;
	private static final double MAX_CAR_SCALE = 2.0;
	private static final Integer MIN_SPEED = -10;
	private static final Integer MAX_SPEED = 10;
	private static int pelotonSpeed;
	
}
