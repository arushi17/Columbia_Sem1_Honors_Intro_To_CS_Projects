import java.awt.*;
import java.awt.geom.*;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
/**
 * Holds methods for drawing a Car and its Exhaust ellipses
 * Private fields are all constants to draw pieces of the Car relative to each other and a unit
 * Code derived from StickFigure class on Courseworks (author John Kender)
 * @author Arushi Sahai as5976
 *
 */
public class Car implements MovingObject {
	
	/**
	 * Car constructor, also creates the Car's Exhaust
	 * @param x
	 * @param y
	 * @param unit
	 */
	public Car(int x, int y, double unit) {
		this.x = x;
		this.y = y;
		this.unit = unit; 
		this.exhaust = new Exhaust(MAX_ELLIPSE_SIZE * unit, MIN_ELLIPSE_SIZE * unit, NUM_EXHAUST);
	}
	
	/**
	 * Implements MovingObject
	 */
	public void translate(int xChange, int yChange) {
		x += xChange;
		y += yChange;
	}
	
	/**
	 * Draws the Car and its Exhaust ellipses
	 */
	public void draw(Graphics2D g2D) {
		double carWidth = unit * CAR_WIDTH;
		double carHeight = unit * CAR_HEIGHT;
		double wheelSize = unit * WHEEL_SIZE;
		double headSize = unit * HEAD_SIZE;
		double xPosUnit = unit * CAR_WIDTH / X_POS_DIVIDER;
				
		// draw rectangle of car
		Rectangle2D.Double carBody = new Rectangle2D.Double(x, y, carWidth, carHeight);
		
		// draw head of driver
		Ellipse2D.Double head = new Ellipse2D.Double(x + headSize * 3, y - unit, headSize, headSize);
		
		// draw wheels
		Ellipse2D.Double leftWheel = new Ellipse2D.Double(x + xPosUnit * 0.5, y + carHeight, wheelSize, wheelSize);
		Ellipse2D.Double rightWheel = new Ellipse2D.Double(x + xPosUnit * 3, y + carHeight, wheelSize, wheelSize);

		// draw wind shield
		Line2D.Double windShield = new Line2D.Double(x + xPosUnit * 4, y, x + xPosUnit * 3.5, y - unit * 1.5);
		
		// aggregate carBody, head, leftWheel, rightWheel, windShield using one GeneralPath
		GeneralPath car = new GeneralPath();
		car.append(carBody, false);
		car.append(head, false);
		car.append(leftWheel, false);
		car.append(rightWheel, false);
		car.append(windShield, false);
		
		// draw the figure
		exhaust.draw(g2D, x, y);
		g2D.draw(car);
		g2D.fill(carBody);
		g2D.fill(head);
		g2D.fill(leftWheel);
		g2D.fill(rightWheel);
	}
	
	/**
	 * getter for unit
	 * @return
	 */
	public double getUnit() {
		return unit;
	}
	
	/**
	 * getter for CAR_HEIGHT multiplier
	 * @return
	 */
	public static double getCarHeight() {
		return CAR_HEIGHT;
	}
	
	private int x;
	private int y;
	private double unit;
	private final double CAR_WIDTH = 6.0;
	private static final double CAR_HEIGHT = 2.0;
	private final double WHEEL_SIZE = 2.0;
	private final double HEAD_SIZE = 1.0;
	private final double X_POS_DIVIDER = 5.0;
	private final double MIN_ELLIPSE_SIZE = 1.0;
	private final double MAX_ELLIPSE_SIZE = 2.0;
	private final int NUM_EXHAUST = 5;
	private Exhaust exhaust;

}
