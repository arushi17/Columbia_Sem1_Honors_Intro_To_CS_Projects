import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import javax.swing.Timer;

/**
 * contains description for a ThrowObject, a String in the Applet
 * @author Arushi Sahai as5976
 *
 */
public class ThrowObject {

	/**
	 * throwobject constructor
	 * @param width
	 * @param height
	 */
	public ThrowObject(int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	/**
	 * setter for throwfont
	 * @param throwFont
	 */
	public void setThrowFont(Font throwFont) {
		this.throwFont = throwFont;
	}
	
	/**
	 * setter for throwobjectname
	 * @param throwObjectName
	 */
	public void setThrowObjectName(String throwObjectName) {
		this.throwObjectName = throwObjectName;
	}
	
	/**
	 * setter for throwx
	 * @param throwX
	 */
	public void setThrowX(int throwX) {
		this.throwX = throwX;
	}
	
	/**
	 * setter for throwy
	 * @param throwY
	 */
	public void setThrowY(int throwY) {
		this.throwY = throwY;
	}
	
	/**
	 * setter for xdir
	 * @param xDir
	 */
	public void setXDir(int xDir) {
		this.xDir = xDir;
	}
	
	/**
	 * setter for ydir
	 * @param yDir
	 */
	public void setYDir(int yDir) {
		this.yDir = yDir;
	}
	
	/**
	 * getter for throwobjectname
	 * @return
	 */
	public String getName() {
		return throwObjectName;
	}
	
	/**
	 * getter for shape
	 * @return
	 */
	public Shape getCurrentBounds() {
		return currentRect;
	}

	/**
	 * draws a throwobject
	 * @param g
	 */
	public void redraw(Graphics g) {
		drawStringFonts(g);
		
		Graphics2D g2D = (Graphics2D) g;
		FontRenderContext throwContext = g2D.getFontRenderContext();
		throwRectangle = throwFont.getStringBounds(throwObjectDisplayName, throwContext);
		
		throwX+=xDir;
		throwY+=yDir;
		
		if (throwX + throwRectangle.getWidth() < 0)
			throwX = width;
		else if (throwX > width)
			throwX = (int) (0 - throwRectangle.getWidth());
		if (throwY + throwRectangle.getHeight() < 0)
			throwY = height;
		else if (throwY > height)
			throwY = (int) (0 - throwRectangle.getHeight());
		
		// source of code: https://stackoverflow.com/questions/8793732/java-translate-rectangle-2d
		AffineTransform at = AffineTransform.getTranslateInstance(throwX, throwY);
		currentRect = at.createTransformedShape(throwRectangle);
		
		g.setFont(throwFont);
		g.drawString(throwObjectDisplayName, throwX, throwY);
	}
	
	private void drawStringFonts(Graphics g) {
		switch (throwObjectName) {
		case "Rock":
			throwFont = new Font("Damascus", Font.BOLD, 40);
			throwObjectDisplayName = "rOCk";
			g.setColor(Color.darkGray);
			break;
		case "Paper":
			throwFont = new Font("Papyrus", Font.ITALIC, 20);
			throwObjectDisplayName = "Paper";
			g.setColor(Color.lightGray);
			break;
		case "Scissors":
			throwFont = new Font("Marker Felt", Font.PLAIN, 30); // CHANGE THIS IF I HAVE TIME!!!!!!!!!
			throwObjectDisplayName = "SCIssORS";
			g.setColor(Color.red);
			break;
		case "Lizard":
			throwFont = new Font("Chalkduster", Font.ITALIC, 20);
			throwObjectDisplayName = "Lizard";
			g.setColor(Color.green);
			break;
		case "Spock":
			throwFont = new Font("Iowan Old Style", Font.PLAIN, 40);
			throwObjectDisplayName = "Spock";
			g.setColor(Color.blue);
			break;
		default:
			break;
		}
	}
	
	private String throwObjectName;
	private Font throwFont;
	private Rectangle2D throwRectangle;
	private String throwObjectDisplayName;
	private int throwX;
	private int throwY;
	private int xDir;
	private int yDir;
	private int width;
	private int height;
	private Shape currentRect;
}
