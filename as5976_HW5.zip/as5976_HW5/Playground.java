import java.applet.Applet;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;

import javax.swing.Timer;

/**
 * @author Arushi Sahai as5976
 * based on code by @author jrk based on cay horstmann
 *
 * Contains methods for running the Applet, aggregates ThrowObjects and DeathStars.
 * TESTING: see Playground.html file (used to generate what is seen in the video)
 */
public class Playground extends Applet {

	/**
	 * Idioms for applet initialization, mostly to get parameters; use
	 * convention that incoming parameters are prefixed with "html"
	 */
	public void init() {
		rules = new HashMap<String,String[]>();
		
		// loser, winner pairs
		rules.put("Rock", new String[] {"Paper", "Spock"});
		rules.put("Paper", new String[] {"Scissors", "Lizard"});
		rules.put("Scissors", new String[] {"Rock", "Spock"});
		rules.put("Lizard", new String[] {"Rock", "Scissors"});
		rules.put("Spock", new String[] {"Paper", "Lizard"});
		
		Graphics2D g2D = (Graphics2D) getGraphics();		
		FontRenderContext throwContext = g2D.getFontRenderContext();

		N = Integer.parseInt(getParameter("N"));
		System.out.println(N);
		htmlDelay = Integer.parseInt(getParameter("delay"));
		
		throwObjects = new LinkedList<ThrowObject>();
		
		setParams();
		
		addMouseListener(new MouseHandler());
		deathStars = new ArrayList<DeathStar>();
		
		// timer
		appletTimer = new Timer(htmlDelay, new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				repaint();
			}
		});
	}
	
	/**
	 * starts the timer
	 */
	public void start() {
		appletTimer.start();
	}
	
	/**
	 * stops the timer
	 */
	public void stop() {
		appletTimer.stop();
	}

	/**
	 * destroys the timer
	 */
	public void destroy() {
	}
	
	/**
	 * paints the graphics
	 */
	public void paint(Graphics g) {
		ListIterator<ThrowObject> iterator = throwObjects.listIterator();

		// update and draw each object
		while (iterator.hasNext()) {
			iterator.next().redraw(g);
		}
		
		while(checkForIntersections()) {}	
		
		// draw each death star
		ListIterator<DeathStar> iteratorD = deathStars.listIterator();
		while (iteratorD.hasNext()) {
			iteratorD.next().redraw((Graphics2D) g);
		}
	}
	
	/**
	 * while this method could be broken up, it also makes logical sense for all the parameter setting to be in one place
	 */
	private void setParams() {
		for (int i = 1; i <= N; i++) {
			String throwObjectNum = String.format("%02d", i);
			ThrowObject newThrowObject = new ThrowObject(getWidth(), getHeight());
			
			throwObjectName = getParameter("throw" + throwObjectNum);
			newThrowObject.setThrowObjectName(throwObjectName);
			
			htmlFontName = getParameter("fontname");
			int htmlFontSize = Integer.parseInt(getParameter("fontsize"));
			throwFont = new Font(htmlFontName, Font.BOLD, htmlFontSize);
			newThrowObject.setThrowFont(throwFont);
			
			String xDirStr = getParameter("xDir" + throwObjectNum);
			if (xDirStr == null) {
				xDirStr = getParameter("xDir");
			}
			xDir = Integer.parseInt(xDirStr);
			newThrowObject.setXDir(xDir);
			
			String yDirStr = getParameter("yDir" + throwObjectNum);
			if (yDirStr == null) {
				yDirStr = getParameter("yDir");
			}
			yDir = Integer.parseInt(yDirStr);
			newThrowObject.setYDir(yDir);

			String xOrigStr = getParameter("xOrig" + throwObjectNum);
			if (xOrigStr == null) {
				xOrigStr = getParameter("xOrig");
			}
			throwX = Integer.parseInt(xOrigStr);
			newThrowObject.setThrowX(throwX);

			String yOrigStr = getParameter("yOrig" + throwObjectNum);
			if (yOrigStr == null) {
				yOrigStr = getParameter("yOrig");
			}
			throwY = Integer.parseInt(yOrigStr);
			newThrowObject.setThrowY(throwY);
			
			throwObjects.add(newThrowObject);
		}
	}
	
	// decisions made about intersecting: once an object gets removed after collision, others are compared 
	private boolean checkForIntersections() {
		boolean hasIntersected = false;
		for (int i = 0; i < throwObjects.size(); i++){
			hasIntersected = throwObjectIntersections(i);
			hasIntersected = deathStarIntersections(i);
		}
		return hasIntersected;
	}
	
	private boolean throwObjectIntersections(int i) {
		for (int j = i + 1; j < throwObjects.size(); j++){
			if (isIntersecting(throwObjects.get(i), throwObjects.get(j))) {
		        int winner = determineWinner(throwObjects.get(i), throwObjects.get(j));
		        if (winner == -1) {
		        	throwObjects.remove(i);
		        	return true;
		        }
		        else if (winner == 1) {
		        	throwObjects.remove(j);
		        	return true;
		        }
		     }
		}
		return false;
	}
	
	private boolean deathStarIntersections(int i) {
		for (int j = 0; j < deathStars.size(); j++) {
			Rectangle2D rect = (Rectangle2D) throwObjects.get(i).getCurrentBounds().getBounds2D();
			if (deathStars.get(j).getDeathStarShape().intersects(rect)) {
				throwObjects.remove(i);
				return true;
			}
		}
		return false;
	}
	
	// like a compareTo: 1 means throw1 wins, -1 means throw2 wins, 0 means neither win
	private int determineWinner(ThrowObject throw1, ThrowObject throw2) {
		String[] winArray = rules.get(throw1.getName());
		if (winArray[0].equals(throw2.getName()) || winArray[1].equals(throw2.getName())) {
			return -1;
		}
		else if (throw1.getName().equals(throw2.getName())) {
			return 0;
		}
		else {
			return 1;
		}
	}
	
	private boolean isIntersecting(ThrowObject throw1, ThrowObject throw2) {
		if (throw1.getCurrentBounds().intersects(throw2.getCurrentBounds().getBounds2D())) {
			return true;
		}
		else {
			return false;
		}
	}
	
	// MouseHandler is an inner class that implements the MouseListener.
	// @author jrk
	// Each method simply prints out a message to the command line.
	private class MouseHandler implements MouseListener {
		public void mousePressed(MouseEvent e) {
		}

		public void mouseClicked(MouseEvent e) {
			deathStars.add(new DeathStar(e.getX(), e.getY()));
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}
	}

	private static HashMap<String,String[]> rules;
	private int N;
	private LinkedList<ThrowObject> throwObjects;
	private int htmlDelay;
	private Timer appletTimer;
	private String throwObjectName;
	private String htmlFontName;
	private Font throwFont;
	private int throwX;
	private int throwY;
	private int xDir;
	private int yDir;
	private ArrayList<DeathStar> deathStars;
}
