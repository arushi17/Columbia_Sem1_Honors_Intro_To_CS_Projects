import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;

/**
 * DeathStar object - the black hole that erases ThrowObjects when touched
 * @author Arushi Sahai as5976
 *
 */
public class DeathStar {
	
	/**
	 * constructor for a deathStar
	 * @param x
	 * @param y
	 */
	public DeathStar(int x, int y) {
		this.x = x;
		this.y = y;
		blackHole = new Ellipse2D.Double(x, y, 30, 30); 
	}
	
	/**
	 * draws a deathStar
	 * @param g2D
	 */
	public void redraw(Graphics2D g2D) {
		blackHole = new Ellipse2D.Double(x, y, 30, 30); 
		g2D.setColor(Color.black);
		g2D.fill(blackHole);
	}
	
	/*8
	 * getter for deathStar shape
	 */
	public Shape getDeathStarShape() {
		return blackHole;
	}

	private int x;
	private int y;
	private Ellipse2D.Double blackHole;
}
